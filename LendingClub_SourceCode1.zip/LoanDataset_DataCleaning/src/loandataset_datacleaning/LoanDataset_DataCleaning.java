/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_datacleaning;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.lib.IdentityReducer;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_DataCleaning {

    
    public static class Map extends Mapper<Object, Text, Text, Text>{
        private ArrayList<String> filterPurpose;
        private Text wodesc = new Text("wodesc");
        private Text widesc = new Text("widesc");
        
                
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.
            filterPurpose = new ArrayList<String>();
            filterPurpose.add("car");
            filterPurpose.add("credit_card");
            filterPurpose.add("debt_consolidation");
            filterPurpose.add("educational");
            filterPurpose.add("home_improvement");
            filterPurpose.add("house");
            filterPurpose.add("major_purchase");
            filterPurpose.add("medical");
            filterPurpose.add("moving");
            filterPurpose.add("other");
            filterPurpose.add("renewable_energy");
            filterPurpose.add("small_business");
            filterPurpose.add("vacation");
            filterPurpose.add("wedding");
            
            
            
            
        }

        
        
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            try{
                String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
                if(tokens[0].trim().equals("id") 
                        || filterPurpose.contains(tokens[20].trim()) 
                        || tokens[19].trim().equals("")){
                    
                    
                    StringBuilder str = new StringBuilder();
                    for(int i = 0 ; i < tokens.length ;i++){
                        if(i != 19){
                            str.append(tokens[i].trim());
                            if(i < tokens.length -1){
                                str.append(",");
                            }
                            
                        }
                    }
                    
                    if(!tokens[0].trim().equals("id")){
                        context.write(wodesc, new Text(str.toString()));
                        if(!tokens[19].trim().equals("") && !(tokens[19].trim().contains(tokens[0].trim()) && tokens[19].trim().contains("http"))){
                            context.write(widesc, new Text(tokens[0].trim() + "\t" + tokens[19].trim()));
                        }
                    }
                }
                
                else{
                    //System.out.println("checkstring\n"+tokens[19]);
                    boolean found = false;
                    int n = 0;
                    StringBuilder nondesc = new StringBuilder();
                    while(n < 19){
                        nondesc.append(tokens[n]);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                        nondesc.append(",");
                        n++;
                    }
                    StringBuilder strdesc = new StringBuilder();
                    while(!found){
                        //System.out.println("tokens["+n+"] = "+tokens[n]);
                        if(filterPurpose.contains(tokens[n].trim())){
                            found = true;
                            nondesc.append(tokens[n]);
                            if(n < tokens.length -1){
                                //System.out.println("FOUND : " + n);
                                nondesc.append(",");
                            }
                            n++;
                            break;
                        }
                        strdesc.append(tokens[n]);
                        n++;
                    }
                    
                    if(!found){
                        System.out.println(value);
                        return;
                    }
                    else{
                        for(int i = n;i<tokens.length;i++){
                            //System.out.println("end : " + n);
                            nondesc.append(tokens[i]);
                            if(n < tokens.length -1){
                                nondesc.append(",");
                            }
                        }
                    }
                    
                    context.write(wodesc, new Text(nondesc.toString()));
                        if(!strdesc.toString().trim().equals("") && !(strdesc.toString().trim().contains("http") && strdesc.toString().trim().contains(tokens[0].trim()))){

                            context.write(widesc, new Text(tokens[0].trim() + "\t" + strdesc.toString()));
                        }
                  
                }
                
                
            }
            catch(Exception e){
                System.out.println("Map Error\n"+e.getMessage()+"\n"+value);
            }
         
            
        }
        
    }
      
    public static class Reduce extends Reducer<Text, Text, NullWritable, Text>{
        private NullWritable redVal = NullWritable.get();  
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            
            for(Text value : values){
                context.write(redVal,value);
            }
            
        }
    
    
    
    }
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         try{
            Configuration conf = new Configuration();



            Job job = Job.getInstance(conf, "inflationratewithinterest");

            job.setJarByClass(LoanDataset_DataCleaning.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(Text.class);
            job.setMapOutputValueClass(Text.class);
            job.setNumReduceTasks(2);
            job.setReducerClass(Reduce.class);
            //job.setCombinerClass(InterestRateAverageReducer.class);
            job.setPartitionerClass(RemoveDescriptionsPartitioner.class);
            job.setOutputKeyClass(NullWritable.class);
            job.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));
            System.exit(job.waitForCompletion(true)?1:0);
        
        }
        catch(IOException| InterruptedException | ClassNotFoundException  e){
            System.out.println("Error\n"+e.getMessage()+"\n"+e);
        }
    }
    
}
