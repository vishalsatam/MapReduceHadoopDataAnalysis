/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_datacleaning;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

/**
 *
 * @author vishalsatam
 */
public class RemoveDescriptionsPartitioner extends Partitioner<Text, Text>{

    private Text wodesc = new Text("wodesc");
    private Text widesc = new Text("widesc");   
    @Override
    public int getPartition(Text key, Text value, int i) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(key.equals(wodesc)){
            return 0;
        }
        else if(key.equals(widesc)){
            return 1;
        }
        else{
            System.out.println("Record in Partitioner didn't contain any values");
            return 0;
        }
        
    }
    
}
