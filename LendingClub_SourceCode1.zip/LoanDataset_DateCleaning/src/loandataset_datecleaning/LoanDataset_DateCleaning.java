/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_datecleaning;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_DateCleaning {

    public static class Map extends Mapper<Object, Text, NullWritable, Text>{
        NullWritable mapk = NullWritable.get();
        Text mapV = new Text();
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            try{
                String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
                if(tokens[0].equals("id")){
                    //
                }
                else{
                    
                    tokens[15] = UtilityFunction.cleanDate(tokens[15]);
                    tokens[43] = UtilityFunction.cleanDate(tokens[15]);
                    tokens[45] = UtilityFunction.cleanDate(tokens[15]);
                    tokens[46] = UtilityFunction.cleanDate(tokens[15]);
                    tokens[24] = UtilityFunction.cleanDate(tokens[15]);
                    StringBuilder str = new StringBuilder();
                    for(int i = 0;i < tokens.length; i++){
                        if(i == tokens.length -1){
                            str.append(tokens[i]);
                        }
                        else{
                            str.append(tokens[i]+",");
                        }
                        
                    }
                    
                    mapV.set(str.toString());
                    context.write(mapk,mapV);
                    
                /*
                    if(!tokens[15].equals("")){
                        int year = Integer.parseInt(tokens[15].split("-")[0]) + 2000;
                        tokens[15] = year + "-" + tokens[15].split("-")[1];
                    }
                    if(!tokens[15].equals("")){
                        int year = Integer.parseInt(tokens[43].split("-")[0]) + 2000;
                        tokens[43] = year + "-" + tokens[43].split("-")[1];
                    }
                    if(!tokens[45].equals("")){
                        int year = Integer.parseInt(tokens[45].split("-")[0]) + 2000;
                        tokens[45] = year + "-" + tokens[45].split("-")[1];
                    }
                    if(!tokens[46].equals("")){
                        int year = Integer.parseInt(tokens[46].split("-")[0]) + 2000;
                        tokens[46] = year + "-" + tokens[46].split("-")[1];
                    }
                    
                    if(!tokens[24].equals("")){
                        if(tokens[24].split("-")[0].length() == 2){
                            
                        }
                        int year = Integer.parseInt(tokens[46].split("-")[0]) + 2000;
                        tokens[46] = year + "-" + tokens[46].split("-")[1];
                    }
                    
                    String val = java.util.Arrays.toString(tokens);
                    mapV.set(val);
                    context.write(mapk,mapV);
                */
                }
                
            }
            catch(Exception e){
                System.out.println("Map Error \n"+e.getMessage()+"\n"+value);
            }
            

            
            
        }
        
    }
    
    
    public static class Reduce extends Reducer<NullWritable, Text, NullWritable,Text>{

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.
            context.write(NullWritable.get(),new Text("id,member_id,loan_amnt,funded_amnt,funded_amnt_inv,term,int_rate,installment,grade,sub_grade,emp_title,emp_length,home_ownership,annual_inc,verification_status,issue_d,loan_status,pymnt_plan,purpose,title,zip_code,addr_state,dti,delinq_2yrs,earliest_cr_line,inq_last_6mths,mths_since_last_delinq,mths_since_last_record,open_acc,pub_rec,revol_bal,revol_util,total_acc,initial_list_status,out_prncp,out_prncp_inv,total_pymnt,total_pymnt_inv,total_rec_prncp,total_rec_int,total_rec_late_fee,recoveries,collection_recovery_fee,last_pymnt_d,last_pymnt_amnt,next_pymnt_d,last_credit_pull_d,collections_12_mths_ex_med,mths_since_last_major_derog,policy_code,application_type,annual_inc_joint,dti_joint,verification_status_joint,acc_now_delinq,tot_coll_amt,tot_cur_bal,open_acc_6m,open_il_6m,open_il_12m,open_il_24m,mths_since_rcnt_il,total_bal_il,il_util,open_rv_12m,open_rv_24m,max_bal_bc,all_util,total_rev_hi_lim,inq_fi,total_cu_tl,inq_last_12m"));
        }
        
        
        @Override
        protected void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            for(Text value : values){
                context.write(key,value);
            }
            
        }
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            Job job = Job.getInstance(conf, "clean datess");

            job.setJarByClass(LoanDataset_DateCleaning.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(NullWritable.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(Text.class);
            job.setNumReduceTasks(1);
            job.setReducerClass(Reduce.class);
            //job.setCombinerClass(Reduce.class);
            //job.setPartitionerClass(YearPartitioner.class);
            job.setOutputKeyClass(NullWritable.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            
            
            
            FileOutputFormat.setOutputPath(job, new Path(args[1]));
            


            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
        
    }
    
}
