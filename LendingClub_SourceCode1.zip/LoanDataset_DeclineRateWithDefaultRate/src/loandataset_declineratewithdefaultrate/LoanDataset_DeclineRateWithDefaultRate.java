/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_declineratewithdefaultrate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_DeclineRateWithDefaultRate {

    public static class Map extends Mapper<Object, Text, Text, IntWritable>{
        Text mapk = new Text();
        IntWritable val = new IntWritable(1);
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            try{
                String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
                if(tokens[6].equals("") || tokens[6].equals("State")){
                    return;
                }
                mapk.set(tokens[6]);
                context.write(mapk,val);
            
            }
            catch(Exception e){
                System.out.println("Map Error \n"+e.getMessage()+"\n"+value);
            }
            
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.
            Configuration conf = context.getConfiguration(); 
            Path[] files = DistributedCache.getLocalCacheFiles(conf);
          if(files == null){
              System.out.println("files was null");
              return;
          }
        }
        
    }
    
    
    public static class Reduce extends Reducer<Text, IntWritable, Text, Text>{

        private java.util.Map<String,Double> defaultrate = new HashMap<String,Double>();
        
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.
            Configuration conf = context.getConfiguration();

          Path[] files = DistributedCache.getLocalCacheFiles(conf);
          if(files == null){
              System.out.println("files was null in reduce");
              return;
          }
            
           System.out.println("length of files = "+ files.length);
           for(Path p : files){
              System.out.println(p.getName());
              
               if(p.getName().equals("part-r-00000")){
               
               try{
                   File f = new File(p.getName());
                   BufferedReader reader = new BufferedReader(new FileReader(f));
                   String line = reader.readLine();
                   while(line!=null){
                       String [] tokens = line.split("\t");
                       defaultrate.put(tokens[0].trim().toUpperCase(), Double.parseDouble(tokens[1].trim()));
                       //System.out.println("State name = "+ tokens[1].trim() +" : Value = "+stateCodes.get(tokens[1].trim()));
                       
                       line = reader.readLine();
                   }
                   context.write(new Text("State Code"),new Text("Rejected Loans\tDefault rate"));
               }
               catch(FileNotFoundException e){
                   System.out.println("File Not found -"+e);
               
               }
               catch(IOException e){
                   System.out.println("IO - " + e);
               }
             }
              
           }
        }

        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            long count = 0;
            for(IntWritable value : values){
                count+=value.get();
            }
            
            Double rate = (Double)defaultrate.get(key.toString());
            if(rate == null){
                System.out.println(key);  
            }
            
            else{
                context.write(key,new Text(count+"\t"+rate));
            }
            
            
        }
        
        
        
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            DistributedCache.addCacheFile(new URI(args[1]), conf);
            Job job = Job.getInstance(conf, "joindeclineanddefaultrate");

            job.setJarByClass(LoanDataset_DeclineRateWithDefaultRate.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(Text.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(IntWritable.class);
            //job.setNumReduceTasks(1);
            job.setReducerClass(Reduce.class);
            //job.setCombinerClass(Reduce.class);
            //job.setPartitionerClass(YearPartitioner.class);
            job.setOutputKeyClass(Text.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            
            
            
            FileOutputFormat.setOutputPath(job, new Path(args[2]));
            


            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException | URISyntaxException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
    }
    
}
