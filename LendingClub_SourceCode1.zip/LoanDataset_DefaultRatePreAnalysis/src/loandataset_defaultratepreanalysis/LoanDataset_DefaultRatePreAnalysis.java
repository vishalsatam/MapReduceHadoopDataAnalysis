/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_defaultratepreanalysis;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_DefaultRatePreAnalysis {

    public static class Map extends Mapper<Object, Text, Text, Text>{
        private Text mapK = new Text();
        private Text mapV =  new Text();
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            try{
            String[]  tokens = UtilityFunction.parseCSVLine(value.toString());

            if(tokens[5].trim().equals("") || tokens[16].trim().equals("") || tokens[0].trim().equals("id")){
                return;
            }
            /*
            if(!tokens[16].trim().equals("") && (tokens[16].trim().contains("Charged Off"))){
                context.write(new Text(tokens[4]),new LongWritable(1));
            }
            */
            mapK.set(tokens[5].trim());
            mapV.set(tokens[16].trim());
            context.write(mapK,mapV);
            }
            catch(Exception e){
                System.out.println(e.getMessage()+"Mapper eror \n"+value);
            }
            
        }
        
    }
    

    
    public static class Reduce extends Reducer<Text, Text, Text, DoubleWritable>{

        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            long count = 0;
            long defaults = 0;
            for(Text value : values){
                if(value.toString().contains("Charged Off") || value.toString().contains("Default")){
                    defaults++;
                }
                if(!(value.toString().contains("Issued") || value.toString().contains("Current"))){
                    count++;
                }
                
            }
            if(count>0){
                context.write(key,new DoubleWritable((double)defaults/(double)count));
            }
            
        }
        
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            Job job = Job.getInstance(conf, "partitionintoyears");

            job.setJarByClass(LoanDataset_DefaultRatePreAnalysis.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(Text.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(Text.class);
            //job.setNumReduceTasks(1);
            job.setReducerClass(Reduce.class);
            //job.setCombinerClass(Reduce.class);
            //job.setPartitionerClass(YearPartitioner.class);
            job.setOutputKeyClass(Text.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(DoubleWritable.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));



            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
    }
    
}
