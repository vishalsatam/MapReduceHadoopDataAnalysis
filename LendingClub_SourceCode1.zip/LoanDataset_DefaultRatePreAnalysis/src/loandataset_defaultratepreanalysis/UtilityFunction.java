/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_defaultratepreanalysis;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author vishalsatam
 */
public class UtilityFunction {
    
    private static final Pattern csvPattern = Pattern.compile("\"([^\"]*)\"|(?<=,|^)([^,]*)(?:,|$)");  
        //private final Pattern csvPattern = Pattern.compile("(?:^|,)\s*(?:(?:(?=\")\"([^\"].*?)\")|(?:(?!\")(.*?)))(?=,|$)");
      
    

    
    public static String[] parseCSVLine(String csvLine) {
            Matcher matcher = null;
            ArrayList<String> allMatches = new ArrayList<String>();  
            matcher = csvPattern.matcher(csvLine);
            String match = null;
            int size;
            
            allMatches.clear();
        while (matcher.find()) {
                match = matcher.group(1);
                if (match!=null) {
                    allMatches.add(match);
                }
                else {
                    allMatches.add(matcher.group(2));
                }
            }

            size = allMatches.size();       
            if (size > 0) {
                return allMatches.toArray(new String[size]);
            }
            else {
                return new String[0];
            } 
        }
}
