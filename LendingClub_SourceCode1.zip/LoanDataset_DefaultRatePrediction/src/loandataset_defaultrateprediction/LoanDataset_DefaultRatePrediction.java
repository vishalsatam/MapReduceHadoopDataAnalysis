/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_defaultrateprediction;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_DefaultRatePrediction {

    public static class Map extends Mapper<Object, Text, NullWritable, Text>{

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            try{
                String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
                if(tokens[0].equals("id")){
                    return;
                }
                String stat = "Good Loan";
                if(tokens[16].contains("Default") || tokens[16].contains("Charged Off") || tokens[16].contains("Late")){
                    stat = "Default";
                }
                if(tokens[16].contains("Current") || tokens[16].contains("Issued")){
                    stat = tokens[16];
                }
                
                context.write(NullWritable.get(), new Text(tokens[3] + ","+ tokens[5]+" months" + ","+ tokens[6] + ","+ 
                        tokens[8] + ","+ tokens[12] + ","+ tokens[13] + ","+ tokens[14] + ","+ stat + ","+ 
                        tokens[18] + ","+ tokens[22]));
            }
            catch(Exception e){
                System.out.println(e.getMessage()+"Mapper eror \n"+value);

            }
        }
        
    }
    
    public static class Reduce extends Reducer<NullWritable, Text, NullWritable, Text>{

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.
            context.write(NullWritable.get(),new Text("funded_amnt,term,int_rate,grade,home_ownership,annual_inc,verification_status,loan_status,purpose,dti"));
            
        }

        @Override
        protected void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            for(Text t : values){
                context.write(NullWritable.get(),t);
            }
        }
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            Job job = Job.getInstance(conf, "partitionintoyears");

            job.setJarByClass(LoanDataset_DefaultRatePrediction.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(NullWritable.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(Text.class);
            job.setNumReduceTasks(2);
            job.setReducerClass(Reduce.class);
            //job.setCombinerClass(Reduce.class);
            job.setPartitionerClass(PartitionIntoHistoricAndTest.class);
            job.setOutputKeyClass(NullWritable.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));



            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
        
    }
    
}
