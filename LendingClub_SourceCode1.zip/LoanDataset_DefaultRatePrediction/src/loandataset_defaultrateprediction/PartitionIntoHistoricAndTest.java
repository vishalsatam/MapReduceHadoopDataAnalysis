/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_defaultrateprediction;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

/**
 *
 * @author vishalsatam
 */
public class PartitionIntoHistoricAndTest extends Partitioner<NullWritable, Text>{

    @Override
    public int getPartition(NullWritable key, Text value, int i) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(value.toString().split(",")[7].contains("Current") || value.toString().split(",")[7].contains("Issued")){
            return 1;
        }
        else{
            return 0;
        }
        
    }
    
}
