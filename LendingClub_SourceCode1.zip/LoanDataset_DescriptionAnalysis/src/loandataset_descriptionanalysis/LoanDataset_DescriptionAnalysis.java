/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_descriptionanalysis;

import com.google.common.base.Charsets;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnel;
import com.google.common.hash.Sink;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_DescriptionAnalysis {

    public static class Map extends Mapper<Object, Text, Text, IntWritable>{
        Funnel<String> word = new Funnel<String>(){
            @Override
            public void funnel(String w, Sink into){
                into.putString(w);
            }
        };
        private BloomFilter<String> positiveFilter = BloomFilter.create(word,2100, 0.01);
        private BloomFilter<String> negativeFilter = BloomFilter.create(word,2100, 0.01);
        
        private ArrayList<String> positiveList = new ArrayList<String>();
        private ArrayList<String> negativeList = new ArrayList<String>();
        
       @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.

               File pf = new File("positive-words.txt");
               File nf = new File("negative-words.txt");
         
               System.out.println("filenme = "+ pf.getName());
               System.out.println("filenme = "+ nf.getName());
               
               try{
                   BufferedReader negativeReader = new BufferedReader(new FileReader(nf));
                   String line = negativeReader.readLine();
                   int lineNo = 0;
                   while(line!=null){
                       negativeFilter.put(line.trim().toUpperCase());
                       negativeList.add(line.trim().toUpperCase());
                       line = negativeReader.readLine();
                       if(lineNo == 0){
                           System.out.println("neg:"+line);
                       }
                       lineNo++;
                       
                   }
                   
                   BufferedReader positiveReader = new BufferedReader(new FileReader(pf));
                   line = positiveReader.readLine();
                   lineNo = 0;
                   while(line!=null){
                       positiveFilter.put(line.trim().toUpperCase());
                       positiveList.add(line.trim().toUpperCase());
                       line = positiveReader.readLine();
                       if(lineNo == 0){
                           System.out.println("pos:"+line);
                       }
                       lineNo++;
                       
                   }
                   
               }
               catch(FileNotFoundException e){
                   System.out.println("File Not found -"+e);
               
               }
               catch(IOException e){
                   System.out.println("IO - " + e);
               }
        
               
            
        }

        Text mapK = new Text();
        IntWritable mapV = new IntWritable();
        
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            String[] vals = value.toString().split("\t");
            if(vals[2].equals("")){
                return;
            }
            StringTokenizer tokens = new StringTokenizer(vals[2]);
            int score = 0;
            int pt =0;
            int nt = 0;
            while (tokens.hasMoreTokens()) {
                String tk = tokens.nextToken();
                tk = tk.replaceAll("<br>", "");
                tk = tk.replaceAll("</br>", "");
                tk = tk.replaceAll("</br>", "");
                tk = tk.replaceAll("Borrower", "");
                tk = tk.replaceAll("added", "");
                tk = tk.replaceAll("http", "");
                tk = tk.replaceAll("[^A-Za-z ]", "");
                if(tk.matches("^[1-9]\\d*$") || tk.length() <= 2 || tk.equals("")){
                    continue;
                }
                /*
                if(positiveFilter.mightContain(tk)){
                    if(++pt<=10){
                    System.out.println("pos : "+tk);
                    }
                    score++;
                }
                else if(negativeFilter.mightContain(tk)){
                    
                    if(++nt<=10){
                    System.out.println("neg : "+tk);
                    }
                    score--;
                }
                */
                if(positiveList.contains(tk.trim().toUpperCase())){
                    if(++pt<=10){
                    //System.out.println("pos : "+tk);
                    }
                    score++;
                }
                else if(negativeList.contains(tk.trim().toUpperCase())){
                    
                    if(++nt<=10){
                    //System.out.println("neg : "+tk);
                    }
                    score--;
                }
                
                
            }
            if(vals[1].equals("")){
                return;
            }
            mapK.set(vals[1]);
            mapV.set(score);
            context.write(mapK,mapV);
        }
        
    }
    
    public static class Reduce extends Reducer<Text, IntWritable, Text, DoubleWritable>{

        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            long count = 0;
            long sum = 0;
            for(IntWritable val : values){
                sum += val.get();
                count++;
            }
            if(count > 0){
                context.write(key,new DoubleWritable((double)sum/(double)count));
            }
            else{
                context.write(key,new DoubleWritable(0.0));
            }
            
        }
        
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
        Configuration conf = new Configuration();
        

        
        
        DistributedCache.addCacheFile(new URI(args[2]), conf) ;
        DistributedCache.addCacheFile(new URI(args[3]), conf) ;
        
        Job job = Job.getInstance(conf, "sentiment analysis");    
        job.setJarByClass(LoanDataset_DescriptionAnalysis.class);
        job.setMapperClass(Map.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        //job.setNumReduceTasks(0);
        job.setReducerClass(Reduce.class);
        //job.setCombinerClass(InterestRateAverageReducer.class);
        //job.setPartitionerClass(YearPartitioner.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true)?1:0);
        
        }
        catch(Exception e){
            System.out.println("Builder error\n"+e.getMessage());
        }
    
    }
}