/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_descriptionpreanalysis;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_DescriptionPreAnalysis {

    public static class DescMap extends Mapper<Object, Text,Text,Text>{

        Text mapk  = new Text();
        Text mapv  = new Text();
        
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            String[] tokens = value.toString().split("\t");
            if(tokens[0].trim().equals("id")){
                return;
            }
            mapk.set(tokens[0].trim());
            if(tokens.length < 2){
                return;
            }
            if(tokens[1].equals("")){
                return;
            }
            String x = "DESCRIPTION::::"+ tokens[1].trim();
            if(tokens.length > 2){
                for(int i=2;i<tokens.length;i++){
                    x = x + tokens[i];
                }
            }
            mapv.set(x);

            context.write(mapk,mapv);
            
        }
        
        
        
    }
    
    
    public static class MainMap extends Mapper<Object, Text, Text, Text>{

        Text mapk = new Text();
        Text mapv = new Text();
        
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            try{
                String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
                if(tokens[0].equals("id")){
                    return;
                }
                if(tokens[0].trim().equals("") || tokens[16].equals("")){
                    return;
                }
                
                mapk.set(tokens[0].trim());
                
                String val = "STATUS::::";
                if(tokens[16].trim().contains("Charged Off")){
                    val = val + "Charged Off";
                }
                else if(tokens[16].trim().contains("Fully Paid")){
                    val = val + "Fully Paid";
                }
                else{
                    val = val + tokens[16].trim();
                }
                
                mapv.set(val);
                context.write(mapk,mapv);
                
            }
            catch(Exception e){
                System.out.println("Mapper error\n"+value);
            }
            
            
        }
        
        
        
    }
    
    public static class JoinReduce extends Reducer<Text, Text, Text, Text>{
        Text output = new Text();
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            String stat = "";
            String desc = "";
            try{

            for(Text val : values){
                String[] tokens = val.toString().split("::::");
                if(tokens[0].equals("STATUS")){
                    stat = tokens[1];
                }
                else if(tokens[0].equals("DESCRIPTION")){
                    desc = tokens[1];
                }
            }
            
            if(!stat.equals("") && !desc.equals("")){
                output.set(stat+"\t"+desc);
                context.write(key,output);
            }
            
            }
            catch(Exception e){
                System.out.println("Reducer error \n"+e.getMessage()+"\n"+key);
            }
        }
        
        
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        try{
            Configuration conf = new Configuration();
            Job job = Job.getInstance(conf, "join desc and statuss");

            job.setJarByClass(LoanDataset_DescriptionPreAnalysis.class);

            MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class,DescMap.class);
            MultipleInputs.addInputPath(job, new Path(args[1]), TextInputFormat.class,MainMap.class);
            job.setMapOutputKeyClass(Text.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(Text.class);
            job.setReducerClass(JoinReduce.class);
            job.setOutputKeyClass(Text.class);
            job.setOutputValueClass(Text.class);

            FileOutputFormat.setOutputPath(job, new Path(args[2]));



            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
    
    }
    
}
