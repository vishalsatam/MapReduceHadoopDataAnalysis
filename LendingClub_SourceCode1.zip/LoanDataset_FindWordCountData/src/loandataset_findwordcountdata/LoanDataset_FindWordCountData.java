/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_findwordcountdata;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.bloom.BloomFilter;
import org.apache.hadoop.util.bloom.Key;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_FindWordCountData {

    public static class Map extends Mapper<Object, Text, Text, LongWritable>{

        
        LongWritable count = new LongWritable(1);
        Text mapk = new Text();

        ArrayList<String> wordlist = new ArrayList<String>();
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.

               File pf = new File("positive-words.txt");
               File nf = new File("negative-words.txt");
         
               System.out.println("filenme = "+ pf.getName());
               System.out.println("filenme = "+ nf.getName());
               
               try{
                   BufferedReader negativeReader = new BufferedReader(new FileReader(nf));
                   String line = negativeReader.readLine();
                   int lineNo = 0;
                   while(line!=null){
                       //negativeFilter.put(line.trim());
                       wordlist.add(line.trim().toUpperCase());
                       line = negativeReader.readLine();
                       if(lineNo == 0){
                           System.out.println("neg:"+line);
                       }
                       lineNo++;
                       
                   }
                   
                   BufferedReader positiveReader = new BufferedReader(new FileReader(pf));
                   line = positiveReader.readLine();
                   lineNo = 0;
                   while(line!=null){
                       //positiveFilter.put(line.trim());
                       wordlist.add(line.trim().toUpperCase());
                       line = positiveReader.readLine();
                       if(lineNo == 0){
                           System.out.println("pos:"+line);
                       }
                       lineNo++;
                       
                   }
                   
               }
               catch(FileNotFoundException e){
                   System.out.println("File Not found -"+e);
               
               }
               catch(IOException e){
                   System.out.println("IO - " + e);
               }
        
               
        }
        
        
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            String[] vals = value.toString().split("\t");
            StringTokenizer tokens = new StringTokenizer(vals[2]);
            
            while (tokens.hasMoreTokens()) {
               
                String tk = tokens.nextToken();
                tk = tk.replaceAll("<br>", "");
                tk = tk.replaceAll("</br>", "");
                tk = tk.replaceAll("</br>", "");
                tk = tk.replaceAll("Borrower", "");
                tk = tk.replaceAll("added", "");
                tk = tk.replaceAll("http", "");
                tk = tk.replaceAll("[^A-Za-z ]", "");
                if(tk.matches("^[1-9]\\d*$") || tk.length() <= 2){
                    continue;
                }
                
                if(wordlist.contains(tk.trim().toUpperCase())){
                    mapk.set(tk.toUpperCase());
                    context.write(mapk,count);
                }
                

            }
            
            
        }
        
        
    }
    
    public static class Reduce extends Reducer<Text, LongWritable, Text, LongWritable>{

        @Override
        protected void reduce(Text key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            
            long ct = 0;
            for(LongWritable word : values){
                ct += word.get();
            }
            context.write(key,new LongWritable(ct));
            
        }
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         try{
            Configuration conf = new Configuration();
            DistributedCache.addCacheFile(new URI(args[2]), conf) ;
            DistributedCache.addCacheFile(new URI(args[3]), conf) ;

            Job job = Job.getInstance(conf, "wordcount");

            job.setJarByClass(LoanDataset_FindWordCountData.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(Text.class);
            job.setMapOutputValueClass(LongWritable.class);
            job.setNumReduceTasks(1);
            job.setReducerClass(Reduce.class);
            job.setCombinerClass(Reduce.class);
            //job.setPartitionerClass(Reduce.class);
            job.setOutputKeyClass(Text.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(LongWritable.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));



            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException | URISyntaxException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
        
    }
    
}
