/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_inflationratewithinterestrate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author vishalsatam
 */
public class InflationMapper extends Mapper<Object, Text, Text, Text>{
    java.util.Map<String,Double> inflation = new HashMap<String,Double>();
    private Text mapK = new Text();
    private Text mapV = new Text();
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        
        String[] tokens = value.toString().split("\t");
        mapK.set(tokens[0]);
        mapV.set(tokens[1] + "\t" + inflation.get(tokens[0]));
        context.write(mapK, mapV);
        
    }

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        //super.setup(context); //To change body of generated methods, choose Tools | Templates.
    

   
         File f = new File("inflationrate.csv");
         
         //Path[] files = DistributedCache.getLocalCacheArchives(job.);
           //System.out.println("length of files = "+ files.length);
           //for(Path p : files){
               System.out.println("filenme = "+ f.getName());
               //if(p.getName().equals("statecodenames.csv")){
               
               try{
                   BufferedReader reader = new BufferedReader(new FileReader(f));
                   String line = reader.readLine();
                   int lineNo = 0;
                   ArrayList<String> months = new ArrayList<String>();
                   while(line!=null){
                       String [] tokens = line.split(",");
                       if(lineNo == 0){
                           for(int i = 1; i <= tokens.length -2;i++){
                               months.add(tokens[i]);
                           }
                       }
                       else{
                       
                        String year = tokens[0].trim().substring(2);
                           for(int j = 1;j<tokens.length - 2;j++){
                                inflation.put(months.get(j-1)+"-"+year,Double.parseDouble(tokens[j]));
                           }
                       }
                       
                       //System.out.println("State name = "+ tokens[1].trim() +" : Value = "+stateCodes.get(tokens[1].trim()));
                       
                       line = reader.readLine();
                       lineNo++;
                       
                   }
               }
               catch(FileNotFoundException e){
                   System.out.println("File Not found -"+e);
               
               }
               catch(IOException e){
                   System.out.println("IO - " + e);
               }
        
        
        
    }
    
        
}
    

