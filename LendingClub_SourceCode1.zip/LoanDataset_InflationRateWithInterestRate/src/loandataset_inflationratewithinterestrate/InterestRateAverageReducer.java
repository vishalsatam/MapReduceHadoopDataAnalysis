/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_inflationratewithinterestrate;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author vishalsatam
 */
public class InterestRateAverageReducer extends Reducer<Text, InterestAndAverageWritable, Object, InterestAndAverageWritable>{

    @Override
    protected void reduce(Text key, Iterable<InterestAndAverageWritable> values, Context context) throws IOException, InterruptedException {
        //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
        
        double sum = 0.0;
        long count = 0;
        for(InterestAndAverageWritable i : values){
            sum += i.getInterest() * i.getCount();
            count += i.getCount();
        }
        InterestAndAverageWritable val = new InterestAndAverageWritable((double)sum/(double)count,count);
        context.write(key,val);
    }
    
}
