/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_inflationratewithinterestrate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author vishalsatam
 */
public class InterestRateAvgMapper extends Mapper<Object, Text, Text, InterestAndAverageWritable>{
    private final Long ct = new Long(1);
    Text mapKey = new Text();
    

    
    
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        try{
        String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
        if(tokens[0].equals("id")){
            
            return;
        }
        
        if(tokens[6].trim().equals("")){
            //interest rate
            System.out.println(value);
            return;
        }
        
        if(tokens[15].trim().equals("")){
            //issue date MMM-YYYY
            System.out.println(value);
            return;
        }
        
        if(tokens[23].trim().equals(""))
        {
            //state
            System.out.println(value);
            return;
        }
        int n = 23;
        String state = "";
        boolean match = false;
        if(tokens[n].trim().length() ==2){
            state = tokens[n].trim();
        }
        else{
            while(!match){
                n++;
                if(tokens[n].trim().length() ==2){
                   state = tokens[n].trim();
                   match = true;
                }
            }
        }
        if(state.equals(""))
        {
            //state
            System.out.println(value);
            return;
        }
        
        String issueDate = "";
        n = 15;
        match = false;
        if(tokens[n].trim().length() == 6 && tokens[n].trim().contains("-")){
            issueDate = tokens[n].trim();
        }
        else{
            while(!match){
                n++;
                if(tokens[n].trim().length() ==6 && tokens[n].trim().contains("-")){
                   issueDate = tokens[n].trim();
                   match = true;
                }
            }
        }
        
        if(issueDate.equals("")){
            System.out.println(value);
            return;
        }
        
        InterestAndAverageWritable val = new InterestAndAverageWritable(Double.parseDouble(tokens[6].trim()),ct);
        mapKey.set(issueDate.trim());
        context.write(mapKey,val);
        
        }
        catch(IOException| InterruptedException  e){
            System.out.println("Error\n"+e.getMessage());
        }
        
    }
    
}
