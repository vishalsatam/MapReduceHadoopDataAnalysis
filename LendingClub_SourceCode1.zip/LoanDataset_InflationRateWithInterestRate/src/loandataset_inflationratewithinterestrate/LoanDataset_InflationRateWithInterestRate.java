/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_inflationratewithinterestrate;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_InflationRateWithInterestRate {

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try{
        Configuration conf = new Configuration();
        

        
        Job job = Job.getInstance(conf, "inflationratewithinterest");
        
        job.setJarByClass(LoanDataset_InflationRateWithInterestRate.class);
        job.setMapperClass(InterestRateAvgMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(InterestAndAverageWritable.class);
        //job.setNumReduceTasks(1);
        job.setReducerClass(InterestRateAverageReducer.class);
        job.setCombinerClass(InterestRateAverageReducer.class);
        //job.setPartitionerClass(YearPartitioner.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(InterestAndAverageWritable.class);
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[2]));
        
        
        
        if(job.waitForCompletion(true)){
            //System.exit(1);
            
            Configuration conf1 = new Configuration();
            DistributedCache.addCacheFile(new URI(args[1]), conf1);
            Job job1 = Job.getInstance(conf1, "mapsidejoin");

            job1.setJarByClass(LoanDataset_InflationRateWithInterestRate.class);
            job1.setMapperClass(InflationMapper.class);
            job1.setMapOutputKeyClass(Text.class);
            job1.setMapOutputValueClass(Text.class);
            job1.setNumReduceTasks(1);
            //job.setReducerClass(InterestRateAverageReducer.class);
            //job.setCombinerClass(InterestRateAverageReducer.class);
            //job.setPartitionerClass(YearPartitioner.class);
            //job.setOutputKeyClass(Text.class);
            //job.setOutputValueClass(InterestAndAverageWritable.class);

            FileInputFormat.addInputPath(job1, new Path(args[2] + "/part-r-00000"));
            FileOutputFormat.setOutputPath(job1, new Path(args[3]));
            
            System.exit(job1.waitForCompletion(true)?1:0);
            
        }
        }
        catch(IOException| InterruptedException | ClassNotFoundException | URISyntaxException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
    }
    
}
