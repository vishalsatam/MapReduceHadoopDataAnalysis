/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_interestavg;

import java.io.IOException;
import java.util.Random;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_InterestAvg {

    
    public static class Map extends Mapper<Object, Text, Text, DoubleWritable>{

        private Text mapK = new Text();
        private DoubleWritable mapV = new DoubleWritable();

        
        
        
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            try{
                String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
                //System.out.println("State : " +tokens[21] +" interest : "+tokens[6]);
                if(tokens[0].equals("id")){
                    return;
                }
                if(tokens[6].trim().equals("")){
                    return;
                }
                if(tokens[50].trim().equals("")){
                    return;
                }
                
                
  
                mapK.set(tokens[50].trim());
                mapV.set(Double.parseDouble(tokens[6].trim()));
                
                context.write(mapK,mapV);
                
            }
            catch(Exception e){
                System.out.println("Mapper error\n"+e.getMessage()+"\n"+value);
            }
        }
        
    }

    public static class Reduce extends Reducer<Text, DoubleWritable, Text, DoubleWritable>{

        @Override
        protected void reduce(Text key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            double interest = 0.0;
            long count = 0;
            for(DoubleWritable d : values){
                interest += d.get();
                count++;
            }
            if(count>0){
                context.write(key,new DoubleWritable((double)interest/(double)count));
            }
            
        }
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try{
            Configuration conf = new Configuration();
            Job job = Job.getInstance(conf, "interestavgbystate");

            job.setJarByClass(LoanDataset_InterestAvg.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(Text.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(DoubleWritable.class);
            //job.setNumReduceTasks(1);
            job.setReducerClass(Reduce.class);
            //job.setCombinerClass(Reduce.class);
            //job.setPartitionerClass(YearPartitioner.class);
            job.setOutputKeyClass(Text.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(DoubleWritable.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));



            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
        
    }
    
}
