/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linregestimates;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_LinRegEstimates {

    public static class Map extends Mapper<Object, Text, NullWritable, Text>{

        NullWritable mapk = NullWritable.get();
        Text mapV = new Text();
        
        Double coefA = 0.0;
        Double coefB = 0.0;
        
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            //super.setup(context); //To change body of generated methods, choose Tools | Templates.
            coefA = Double.parseDouble(context.getConfiguration().get("coefA"));
            coefB = Double.parseDouble(context.getConfiguration().get("coefB"));
        }

        
        
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            try{
                String[] tokens = value.toString().split("\t");
                Double actualInterest = Double.parseDouble(tokens[0].trim());
                Double borrowerGrade = Double.parseDouble(tokens[1].trim());
                Double estimatedInterest = coefA + borrowerGrade * coefB;
                Double diff = estimatedInterest - actualInterest;
                mapV.set(borrowerGrade + "\t" + actualInterest + "\t" + estimatedInterest);
                context.write(mapk,mapV);
                
            }
            catch(Exception e){
                System.out.println("Mapper error\n"+e.getMessage()+"\n"+value);
            }
        }
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            conf.set("coefA", "5.359253664637565");
            conf.set("coefB", "0.6595225194868153");
            Job job = Job.getInstance(conf, "score model");

            job.setJarByClass(LoanDataset_LinRegEstimates.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(NullWritable.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(Text.class);
            job.setNumReduceTasks(0);
            //job.setReducerClass(Reduce.class);
            //job.setCombinerClass(Reduce.class);
            //job.setPartitionerClass(PrepareDataPartitioner.class);
            //job.setOutputKeyClass(NullWritable.class);
            //job.setOutputValueClass(Text.class);
            //job.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));
            
            System.exit(job.waitForCompletion(true)?1:0);

        }
        catch(Exception e){
            System.out.println("Error occurred in builder\n"+e.getMessage());
        }
        
    }
    
}
