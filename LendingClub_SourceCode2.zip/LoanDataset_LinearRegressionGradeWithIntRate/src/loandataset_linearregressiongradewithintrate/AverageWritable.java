/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linearregressiongradewithintrate;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

/**
 *
 * @author vishalsatam
 */
public class AverageWritable implements Writable{

    public Double intAvg;
    public Double borrAvg;
    public Long count;

    public AverageWritable(Double intAvg, Double borrAvg, Long count) {
        this.intAvg = intAvg;
        this.borrAvg = borrAvg;
        this.count = count;
    }

    public Double getIntAvg() {
        return intAvg;
    }

    public void setIntAvg(Double intAvg) {
        this.intAvg = intAvg;
    }

    public Double getBorrAvg() {
        return borrAvg;
    }

    public void setBorrAvg(Double borrAvg) {
        this.borrAvg = borrAvg;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }
    
    public AverageWritable(){
        
    }
    
    @Override
    public void write(DataOutput d) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        d.writeDouble(this.intAvg);
        d.writeDouble(this.borrAvg);
        d.writeLong(this.count);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        this.intAvg = di.readDouble();
        this.borrAvg = di.readDouble();
        this.count = di.readLong();
    }

    @Override
    public String toString() {
        return intAvg + "\t" + borrAvg + "\t" + count;
    }
    
    
    
}
