/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linearregressiongradewithintrate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author vishalsatam
 */
public class LinearRegressionModelReducer extends Reducer<NullWritable, Text, NullWritable, Text>{

    Long numberOfElements;
    double interestMean;
    double borrowerMean;
    
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        //super.setup(context); //To change body of generated methods, choose Tools | Templates.
            File f = new File("part-r-00000");

               System.out.println("filenme = "+ f.getName());

               try{
                   BufferedReader reader = new BufferedReader(new FileReader(f));
                   String line = reader.readLine();
                   int lineNo = 0;
                   ArrayList<String> months = new ArrayList<String>();
                   while(line!=null){
                       String [] tokens = line.split("\t");
                       if(!tokens[0].equals("")){
                           interestMean = Double.parseDouble(tokens[0].trim());
                            borrowerMean = Double.parseDouble(tokens[1].trim());
                            numberOfElements = Long.parseLong(tokens[2].trim());
                            break;
                       }
                       
                       line = reader.readLine();
                       lineNo++;
                       
                   }
               }
               catch(FileNotFoundException e){
                   System.out.println("File Not found -"+e);
               
               }
               catch(IOException e){
                   System.out.println("IO - " + e);
               }
        context.write(NullWritable.get(),new Text("R\tR2\tInterest Mean\tBorrowerGrade Mean\tNumber of Elements\tStandard Deviation Interest Rate\tStandard Deviation Borrower Grade\tIntercept\tCoef X\tModel"));
    }

    
    
    @Override
    protected void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
        
        double xXSquareSum = 0.0;
        double yYSquareSum = 0.0;
        double xXyY = 0.0;
        
        if(numberOfElements <= 0){
            System.out.println("num elements = 0"+numberOfElements);
            return;
        }
        
        for(Text val: values){
            String tokens[] = val.toString().split("\t");
            xXyY += Double.parseDouble(tokens[0]);
            xXSquareSum +=  Double.parseDouble(tokens[1]);
            yYSquareSum += Double.parseDouble(tokens[2]);
        }
        
        double r = (double)xXyY/(double)Math.sqrt(xXSquareSum * yYSquareSum);
        
        double sdX = Math.sqrt((double)xXSquareSum/(double)(numberOfElements -1));
        double sdY = Math.sqrt((double)yYSquareSum/(double)(numberOfElements -1));
        
        double coefB = r * sdY / sdX;
        double intercept = interestMean - (coefB * borrowerMean);
        
        context.write(NullWritable.get(), new Text(r+"\t"+ r*r +"\t"+ interestMean + "\t" + borrowerMean + "\t" + numberOfElements+ "\t"+ sdY + "\t" + sdX +"\t" +intercept + "\t"+ coefB + "\tInterest = " + intercept + " + (" + coefB + " * BorrowerGrade)"));
        
    }
    
}
