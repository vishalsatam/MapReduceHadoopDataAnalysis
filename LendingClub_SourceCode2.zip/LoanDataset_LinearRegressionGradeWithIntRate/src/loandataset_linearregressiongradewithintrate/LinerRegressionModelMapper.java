/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linearregressiongradewithintrate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author vishalsatam
 */
public class LinerRegressionModelMapper extends Mapper<Object, Text, NullWritable, Text>{
    NullWritable mapk = NullWritable.get();
    Text mapV = new Text();

    double interestMean;
    double borrowerMean;
    long numberElements;
    
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {

            File f = new File("part-r-00000");

               System.out.println("filenme = "+ f.getName());

               try{
                   BufferedReader reader = new BufferedReader(new FileReader(f));
                   String line = reader.readLine();
                   int lineNo = 0;
                   ArrayList<String> months = new ArrayList<String>();
                   while(line!=null){
                       String [] tokens = line.split("\t");
                       if(!tokens[0].equals("")){
                           interestMean = Double.parseDouble(tokens[0].trim());
                            borrowerMean = Double.parseDouble(tokens[1].trim());
                            numberElements = Long.parseLong(tokens[2].trim());
                            break;
                       }
                       
                       line = reader.readLine();
                       lineNo++;
                       
                   }
               }
               catch(FileNotFoundException e){
                   System.out.println("File Not found -"+e);
               
               }
               catch(IOException e){
                   System.out.println("IO - " + e);
               }
        
        
        
    }
    
    
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        
        String tokens[] = value.toString().split("\t");
        
        double yY = Double.parseDouble(tokens[0]) - interestMean;
        double xX = Double.parseDouble(tokens[1]) - borrowerMean;
        
        mapV.set(xX*yY + "\t" + xX*xX + "\t" + yY*yY);
        context.write(mapk,mapV);
        
    }
    
}
