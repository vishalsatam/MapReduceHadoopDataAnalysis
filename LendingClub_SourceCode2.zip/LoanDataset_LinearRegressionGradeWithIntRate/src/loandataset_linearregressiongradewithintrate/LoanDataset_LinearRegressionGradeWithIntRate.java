/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linearregressiongradewithintrate;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_LinearRegressionGradeWithIntRate {

    
    public static class AverageMap extends Mapper<Object, Text, NullWritable, AverageWritable>{

        NullWritable mapk = NullWritable.get();
        long ct = 1;
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            try{
            String[]  tokens = value.toString().split("\t");
            //System.out.println("State : " +tokens[21] +" interest : "+tokens[6]);

            if(tokens[0].trim().equals("") || tokens[1].trim().equals("")){
                System.out.println("interest problem\n"+value);
                return;
            }
            
            AverageWritable avg = new AverageWritable(Double.parseDouble(tokens[0]),Double.parseDouble(tokens[1]),ct);
            context.write(mapk,avg);
            
            }catch(Exception e){
                System.out.println("Mapper error\n"+value);
            }
            
        }
        
    }
    
    public static class AverageReduce extends Reducer<NullWritable, AverageWritable, NullWritable, AverageWritable>{

        @Override
        protected void reduce(NullWritable key, Iterable<AverageWritable> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            long ct = 0;
            double intavg = 0.0;
            double borravg = 0.0;
            for(AverageWritable val : values){
                intavg += val.getIntAvg() * val.getCount();
                borravg += val.getBorrAvg() * val.getCount();
                ct += val.getCount();
            }
            if(ct == 0){
                System.out.println("Count = 0");
                return;
            }

            AverageWritable output = new AverageWritable((double)intavg/(double)ct,(double)borravg/(double)ct,ct);
            
            context.write(NullWritable.get(),output);
            
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            //super.cleanup(context); //To change body of generated methods, choose Tools | Templates.

        }
        
        
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            conf.set("filter_percentage", "90.0");
            Job job = Job.getInstance(conf, "interestavgbystate");

            job.setJarByClass(LoanDataset_LinearRegressionGradeWithIntRate.class);
            job.setMapperClass(PrepareDataMapper.class);
            job.setMapOutputKeyClass(Text.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(Text.class);
            job.setNumReduceTasks(2);
            job.setReducerClass(PrepareDataReducer.class);
            //job.setCombinerClass(Reduce.class);
            job.setPartitionerClass(PrepareDataPartitioner.class);
            job.setOutputKeyClass(NullWritable.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));



            if(job.waitForCompletion(true)){
                //System.exit(1);
                Configuration confAvg = new Configuration();
                Job avgJob = Job.getInstance(confAvg, "findmeanjob");

                avgJob.setJarByClass(LoanDataset_LinearRegressionGradeWithIntRate.class);
                avgJob.setMapperClass(AverageMap.class);
                avgJob.setMapOutputKeyClass(NullWritable.class);
                //job.setMapOutputValueClass(DoubleWritable.class);
                avgJob.setMapOutputValueClass(AverageWritable.class);
                avgJob.setNumReduceTasks(1);
                avgJob.setReducerClass(AverageReduce.class);
                avgJob.setCombinerClass(AverageReduce.class);
                //avgJob.setPartitionerClass(NullWritable.class);
                avgJob.setOutputKeyClass(NullWritable.class);
                //job.setOutputValueClass(Text.class);
                avgJob.setOutputValueClass(AverageWritable.class);

                FileInputFormat.addInputPath(avgJob, new Path(args[1]+"/part-r-00001"));
                FileOutputFormat.setOutputPath(avgJob, new Path("/finalloan/inter")); 
                
                
                if(avgJob.waitForCompletion(true)){
                    Configuration linRegCong = new Configuration();
                    try{
                    DistributedCache.addCacheFile(new URI("/finalloan/inter/part-r-00000"), linRegCong);
                    }
                    catch(URISyntaxException e){
                        System.out.println("URI Exception \n"+e.getMessage());
                    }
                    Job linRegJob = Job.getInstance(linRegCong, "regressionModel");
                    linRegJob.setJarByClass(LoanDataset_LinearRegressionGradeWithIntRate.class);
                    linRegJob.setMapperClass(LinerRegressionModelMapper.class);
                    linRegJob.setMapOutputKeyClass(NullWritable.class);
                    //job.setMapOutputValueClass(DoubleWritable.class);
                    linRegJob.setMapOutputValueClass(Text.class);
                    linRegJob.setNumReduceTasks(1);
                    linRegJob.setReducerClass(LinearRegressionModelReducer.class);
                    //linRegJob.setCombinerClass(AverageReduce.class);
                    //avgJob.setPartitionerClass(NullWritable.class);
                    linRegJob.setOutputKeyClass(NullWritable.class);
                    //job.setOutputValueClass(Text.class);
                    linRegJob.setOutputValueClass(Text.class);

                    FileInputFormat.addInputPath(linRegJob, new Path(args[1]+"/part-r-00001"));
                    FileOutputFormat.setOutputPath(linRegJob, new Path(args[2])); 
                    
                    System.exit(linRegJob.waitForCompletion(true)?1:0);
                }
                
                               
            }
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
    }
    
}
