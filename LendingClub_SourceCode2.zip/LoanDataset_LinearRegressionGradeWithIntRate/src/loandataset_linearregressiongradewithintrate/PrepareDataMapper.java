/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linearregressiongradewithintrate;

import java.io.IOException;
import java.util.Random;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author vishalsatam
 */
public class PrepareDataMapper extends Mapper<Object, Text, Text, Text>{

    Text trainK = new Text("train");
    Text testK = new Text("test");
    Text mapV = new Text();
    private Random rand = new Random();
    private Double percentage;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        //super.setup(context); //To change body of generated methods, choose Tools | Templates.
        String strPercentage = context.getConfiguration().get("filter_percentage");
        percentage =  Double.parseDouble(strPercentage)/(double)100.0;
    }
        
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        
        try{
            String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
            //System.out.println("State : " +tokens[21] +" interest : "+tokens[6]);
            if(tokens[0].equals("id")){
                return;
            }
            if(tokens[6].trim().equals("")){
                System.out.println("interest problem\n"+value);
                return;
            }
            if(tokens[9].trim().equals("") || tokens[9].trim().length()>2){
                System.out.println("grade problem\n"+value);
                return;
            }
            double interest = 0.0;
            if(Double.parseDouble(tokens[6]) > 0.0){
                interest = Double.parseDouble(tokens[6]);
            }else{
                System.out.println("interest problem\n"+value);
                return;
            }
            int totgrade = 0;
            int subgrade = Integer.parseInt(tokens[9].trim().substring(1));
            String subgrhead = tokens[9].substring(0,1);
            if(subgrhead.equals("A")){
                totgrade = subgrade + 0;
            }
            else if(subgrhead.equals("B")){
                totgrade = subgrade + 5;
            }
            else if(subgrhead.equals("C")){
                totgrade = subgrade + 10;
            }
            else if(subgrhead.equals("D")){
                totgrade = subgrade + 15;
            }
            else if(subgrhead.equals("E")){
                totgrade = subgrade + 20;
            }
            else if(subgrhead.equals("F")){
                totgrade = subgrade + 25;
            }
            else if(subgrhead.equals("G")){
                totgrade = subgrade + 30;
            }
            /*
            switch (tokens[9].substring(0,1)){
                case "A": totgrade = subgrade + 0;
                case "B": totgrade = subgrade + 5;
                case "C": totgrade = subgrade + 10;
                case "D": totgrade = subgrade + 15;
                case "E": totgrade = subgrade + 20;
                case "F": totgrade = subgrade + 25;
                case "G": totgrade = subgrade + 30;
                
            }
*/
            if(interest > 0.0){

                mapV.set(tokens[6] + "\t" + totgrade);
                if(rand.nextDouble() <= percentage){
                    context.write(trainK,mapV);
                }
                else{
                    context.write(testK,mapV);
                }
            }
            
        }
        catch(Exception e){
            System.out.println("Mapper error\n"+e.getMessage()+"\n"+value);
        }
        
        
    }
    
}
