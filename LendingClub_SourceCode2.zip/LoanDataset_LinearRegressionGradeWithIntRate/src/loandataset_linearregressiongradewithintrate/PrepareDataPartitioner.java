/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linearregressiongradewithintrate;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

/**
 *
 * @author vishalsatam
 */
public class PrepareDataPartitioner extends Partitioner<Text, Text>{

    @Override
    public int getPartition(Text key, Text value, int i) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       
       if(key.toString().equalsIgnoreCase("test")){
           return 0;
       }
       else{
           return 1;
       }
    }
    
}
