/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_linearregressiongradewithintrate;

import java.io.IOException;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author vishalsatam
 */
public class PrepareDataReducer extends Reducer<Text, Text, NullWritable, Text>{
    NullWritable valK = NullWritable.get();
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.'
        for(Text val : values){
            context.write(valK,val);
        }
    }
    
}
