/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_memberidcounts;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_MemberIdCounts {
public static class MemberIDCounter extends Mapper<Object, Text, Text, IntWritable>{

    Text mapKey = new Text();
    IntWritable d = new IntWritable(1);
    
    @Override
    protected void map(Object key, Text value, Mapper.Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        try{
        String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
        if(tokens[0].equals("id")){
            return;
        }
        
        mapKey.set(tokens[1].trim());
        context.write(mapKey,d);
        }
        catch(Exception e){
            System.out.println(value);
        }
        
    }
    
}

public static class MemberIDCounterReducer extends Reducer<Text, IntWritable, Text, IntWritable>{

        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            int count = 0;
            for(IntWritable value : values){
                count += value.get();
            }
            context.write(key,new IntWritable(count));
        }
    
}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try{
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "top10borrowers");
        
        job.setJarByClass(LoanDataset_MemberIdCounts.class);
        job.setMapperClass(MemberIDCounter.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        //job.setNumReduceTasks(1);
        job.setReducerClass(MemberIDCounterReducer.class);
        job.setCombinerClass(MemberIDCounterReducer.class);
        //job.setPartitionerClass(YearPartitioner.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
   }
    
}
