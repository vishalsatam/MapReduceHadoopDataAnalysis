/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_profitabilitybypurpose;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_ProfitabilityByPurpose {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            Job job = Job.getInstance(conf, "profitability");

            job.setJarByClass(LoanDataset_ProfitabilityByPurpose.class);
            job.setMapperClass(ProfitMapper.class);
            job.setMapOutputKeyClass(Text.class);
            job.setMapOutputValueClass(ProfitMapperWritable.class);
            //job.setNumReduceTasks(1);
            job.setReducerClass(ProfitabilityReducer.class);
            //job.setCombinerClass(MemberIDCounterReducer.class);
            //job.setPartitionerClass(YearPartitioner.class);
            job.setOutputKeyClass(Text.class);
            job.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));

            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
        
    }
    
}
