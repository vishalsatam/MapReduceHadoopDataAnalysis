/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_profitabilitybypurpose;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author vishalsatam
 */
public class ProfitMapper extends Mapper<Object, Text, Text, ProfitMapperWritable>{

    Text mapKey = new Text();
    
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        
        try{
        String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
        if(tokens[0].equals("id")){
            return;
        }
        if(!tokens[16].contains("Current") && !tokens[16].contains("Issued") &&
                !tokens[16].contains("Late") && !tokens[16].contains("Grace")){
            double fundedAmount = Double.parseDouble(tokens[3]);
            double amtRecieved = Double.parseDouble(tokens[36]) + Double.parseDouble(tokens[40])+ Double.parseDouble(tokens[41])
                    - Double.parseDouble(tokens[41]);
            
            double projectedProfit = Integer.parseInt(tokens[5]) * Double.parseDouble(tokens[7]);
            
            ProfitMapperWritable pt = new ProfitMapperWritable(fundedAmount,amtRecieved,projectedProfit);
            mapKey.set(tokens[18]);
            context.write(mapKey,pt);
            
        }

        }
        catch(Exception e){
            System.out.println("Map Error\n"+value);
        }
        
        
    }
    
}
