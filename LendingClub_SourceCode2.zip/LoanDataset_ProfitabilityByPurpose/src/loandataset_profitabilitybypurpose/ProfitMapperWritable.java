/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_profitabilitybypurpose;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

/**
 *
 * @author vishalsatam
 */
public class ProfitMapperWritable implements Writable{
    
    private double fundedAmount;
    private double amtRecieved;

    private double projectedProfit;

    public double getFundedAmount() {
        return fundedAmount;
    }

    public void setFundedAmount(double fundedAmount) {
        this.fundedAmount = fundedAmount;
    }

    public double getAmtRecieved() {
        return amtRecieved;
    }

    public void setAmtRecieved(double amtRecieved) {
        this.amtRecieved = amtRecieved;
    }

    public double getProjectedProfit() {
        return projectedProfit;
    }

    public void setProjectedProfit(double projectedProfit) {
        this.projectedProfit = projectedProfit;
    }

    public ProfitMapperWritable(double fundedAmount, double amtRecieved, double projectedProfit) {
        this.fundedAmount = fundedAmount;
        this.amtRecieved = amtRecieved;
        this.projectedProfit = projectedProfit;
    }

    public ProfitMapperWritable(){
        
    }
    
    @Override
    public void write(DataOutput d) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        d.writeDouble(this.fundedAmount);
        d.writeDouble(this.amtRecieved);
        d.writeDouble(this.projectedProfit);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.fundedAmount = di.readDouble();
        this.amtRecieved = di.readDouble();
        this.projectedProfit = di.readDouble();
    }
    
}
