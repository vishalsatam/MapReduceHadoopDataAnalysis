/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_profitabilitybypurpose;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author vishalsatam
 */
public class ProfitabilityReducer extends Reducer<Text, ProfitMapperWritable, Text, Text>{

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        //super.setup(context); //To change body of generated methods, choose Tools | Templates.
        context.write(new Text("Purpose"),new Text("Total Loans\tAmount Recieved\tProjected Amount\tFunded Amount\tProfit\tProfit(%)\tDeficit Amount\tDeficit Amount(%)"));
        
    }

    
    
    @Override
    protected void reduce(Text key, Iterable<ProfitMapperWritable> values, Context context) throws IOException, InterruptedException {
        //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
        
        long count = 0;
        double fundedAmount = 0.0;
        double amtRecieved = 0.0;
        double projectedAmt = 0.0;
        for(ProfitMapperWritable value : values){
            fundedAmount += value.getFundedAmount();
            amtRecieved += value.getAmtRecieved();
            projectedAmt += value.getProjectedProfit();
            count++;
            System.out.println(count + "\t" + amtRecieved + "\t" + projectedAmt + "\t" + fundedAmount);
        }
        
        
        
        double profit = amtRecieved - fundedAmount;
        double deficit = ((projectedAmt - amtRecieved) > 0)?(projectedAmt - amtRecieved):0;
        
        double profitPer = (double)profit/(double)fundedAmount*(double)100.0;
        
        double deficitPer = (double)deficit/(double)projectedAmt*(double)100.0;
        context.write(key, new Text(count + "\t" + amtRecieved + "\t" + projectedAmt + "\t" + fundedAmount + "\t" + 
                profit + "\t" + profitPer + "\t" + deficit + "\t" + deficitPer));


    }
    
}
