/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_stakeratio;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_StakeRatio {

    public static class Map extends Mapper<Object, Text, Text, StakeRatioWritable>{
        private Text mapK = new Text();
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            try{
                 String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
                if(tokens[18].trim().equals("") || tokens[18].trim().equalsIgnoreCase("purpose")){
                    return;
                }
                //if(tokens[16].contains("Current") || tokens[16].contains("Issued") ||
                //tokens[16].contains("Late") || tokens[16].contains("Grace")){
                    
                double loanAmt = Double.parseDouble(tokens[3]);
                double fundedAmt = Double.parseDouble(tokens[4]);
                StakeRatioWritable st = new StakeRatioWritable(loanAmt,fundedAmt,(double)fundedAmt/(double)loanAmt);

                mapK.set(tokens[18].trim());
                context.write(mapK, st);
                //}
            }
            catch(Exception e){
                System.out.println(e.getMessage()+"\n"+value);
            }
        }
        
    }
    
    public static class Reduce extends Reducer<Text, StakeRatioWritable, Text, StakeRatioWritable>{

        @Override
        protected void reduce(Text key, Iterable<StakeRatioWritable> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            
            double fundedAmount = 0.0;
            double loanAmount = 0.0;
            double ratio = 0.0;
            
            for(StakeRatioWritable st : values){
                fundedAmount += st.getFundedAmount();
                loanAmount += st.getLoanAmount();
            }
            StakeRatioWritable st = new StakeRatioWritable(loanAmount,fundedAmount,(double)fundedAmount/(double)loanAmount);
            context.write(key, st);
            
            
        }
        
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Configuration conf = new Configuration();
            Job job = Job.getInstance(conf, "partitionintoyears");

            job.setJarByClass(LoanDataset_StakeRatio.class);
            job.setMapperClass(Map.class);
            job.setMapOutputKeyClass(Text.class);
            //job.setMapOutputValueClass(DoubleWritable.class);
            job.setMapOutputValueClass(StakeRatioWritable.class);
            //job.setNumReduceTasks(1);
            job.setReducerClass(Reduce.class);
            job.setCombinerClass(Reduce.class);
            //job.setPartitionerClass(YearPartitioner.class);
            job.setOutputKeyClass(Text.class);
            //job.setOutputValueClass(Text.class);
            job.setOutputValueClass(StakeRatioWritable.class);

            FileInputFormat.addInputPath(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));



            System.exit(job.waitForCompletion(true)?1:0);
        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
    }
    
}
