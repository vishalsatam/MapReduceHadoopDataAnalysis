/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_stakeratio;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

/**
 *
 * @author vishalsatam
 */
public class StakeRatioWritable implements Writable{

    double loanAmount;
    double fundedAmount;
    double ratio;

    public double getRatio() {
        return ratio;
    }

    public void setRatio(double ratio) {
        this.ratio = ratio;
    }

    public StakeRatioWritable(double loanAmount, double fundedAmount, double ratio) {
        this.loanAmount = loanAmount;
        this.fundedAmount = fundedAmount;
        this.ratio = ratio;
    }

    
    
    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getFundedAmount() {
        return fundedAmount;
    }

    public void setFundedAmount(double fundedAmount) {
        this.fundedAmount = fundedAmount;
    }

    public StakeRatioWritable(){
        
    }
    
    @Override
    public void write(DataOutput d) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        d.writeDouble(this.loanAmount);
        d.writeDouble(this.fundedAmount);
        d.writeDouble(this.ratio);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.loanAmount = di.readDouble();
        this.fundedAmount = di.readDouble();
        this.ratio = di.readDouble();
        
    }

    @Override
    public String toString() {
        //return super.toString(); //To change body of generated methods, choose Tools | Templates.
        return this.ratio + "";
    }
    
}
