package loandataset_top10borrowers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;

import org.apache.hadoop.hive.serde2.ByteStream.Output;
import org.apache.hadoop.hive.serde2.lazybinary.LazyBinaryUtils;
import org.apache.hadoop.hive.serde2.lazybinary.LazyBinaryUtils.VInt;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.hive.serde2.ByteStream.*;
import org.apache.hadoop.io.Writable;


/**
 * This file is taken from a patch to hive 0.11
 * Issue : https://issues.apache.org/jira/browse/HIVE-2693
 *
 */


 public class BigDecimalWritableCustom implements Writable,WritableComparable<BigDecimalWritableCustom> {
    private BigDecimal value;
    private byte[] internalStorage = new byte[0];
    private int scale = 0;

    public BigDecimalWritableCustom(BigDecimal value) {
      this.value = value;
    }
    
    public BigDecimalWritableCustom() {

    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
      out.writeObject(value);
      out.close();
      byte[] bytes = bos.toByteArray();
      dataOutput.write(bytes.length);
      dataOutput.write(bytes);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {

       //int n = dataInput.readInt();
      /*
       if (n < 0 || n > 1000) {
        throw new IllegalArgumentException("Invalid representation for BigDecimal ... length is " + n);
      }
*/
      byte[] bytes = new byte[1000];
      dataInput.readFully(bytes);
      try {
        value = (BigDecimal) new ObjectInputStream(new ByteArrayInputStream(bytes)).readObject();
      } catch (ClassNotFoundException e) {
        throw new RuntimeException("Unable to read serialized BigDecimal value, can't happen", e);
      }
      
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }
    
    
    
    @Override
  public int compareTo(BigDecimalWritableCustom that) {
    return -1*this.value.compareTo(that.getValue());
  }

    @Override
    public String toString() {
        return value.toPlainString();
    }
  
  
  
  }