/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_top10borrowers;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author vishalsatam
 */
public class LoanDataset_Top10Borrowers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "top10borrowers");
        
        job.setJarByClass(LoanDataset_Top10Borrowers.class);
        job.setMapperClass(TotalLoanAmountMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DoubleWritable.class);
        //job.setNumReduceTasks(1);
        job.setReducerClass(TotalLoanAmountReducer.class);
        //job.setCombinerClass(TotalLoanAmountReducer.class);
        //job.setPartitionerClass(YearPartitioner.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(BigDecimalWritableCustom.class);
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        
        if(job.waitForCompletion(true)){
            Configuration confNew = new Configuration();
            Job job1 = Job.getInstance(confNew, "top25");

            job1.setJarByClass(LoanDataset_Top10Borrowers.class);
            job1.setMapperClass(Top10Mapper.class);
            job1.setMapOutputKeyClass(TotalLoanByBorrowerComposite.class);
            job1.setMapOutputValueClass(NullWritable.class);
            //job.setNumReduceTasks(1);
            job1.setReducerClass(Top10Reducer.class);
            //job.setCombinerClass(TotalLoanAmountReducer.class);
            //job.setPartitionerClass(YearPartitioner.class);
            job1.setOutputKeyClass(TotalLoanByBorrowerComposite.class);
            job1.setOutputValueClass(NullWritable.class);

            FileInputFormat.addInputPath(job1, new Path(args[1] + "/part-r-00000"));
            FileOutputFormat.setOutputPath(job1, new Path(args[2]));
            
            System.exit(job1.waitForCompletion(true)?1:0);
        }

        }
        catch(IOException| InterruptedException | ClassNotFoundException e){
            System.out.println("Error\n"+e.getMessage());
        }
        
    }
    
}
