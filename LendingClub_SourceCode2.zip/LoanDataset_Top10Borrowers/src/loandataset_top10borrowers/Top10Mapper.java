/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_top10borrowers;

import java.io.IOException;
import java.math.BigDecimal;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.NullWritable;


/**
 *
 * @author vishalsatam
 */
public class Top10Mapper extends Mapper<Object, Text, TotalLoanByBorrowerComposite, NullWritable>{
    Text mapK = new Text();
    NullWritable val = NullWritable.get();
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        try{
        String[] tokens = value.toString().split("\t");
        mapK.set(tokens[0]);
        
        TotalLoanByBorrowerComposite x = new TotalLoanByBorrowerComposite(tokens[0].trim(),tokens[1].trim());
        context.write(x,val);
        
        }
        catch(Exception e){
            System.out.println(value);
        }
    }

}
