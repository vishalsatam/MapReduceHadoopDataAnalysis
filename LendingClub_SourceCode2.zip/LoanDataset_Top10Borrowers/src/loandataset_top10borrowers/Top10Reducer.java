/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_top10borrowers;

import java.io.IOException;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author vishalsatam
 */
public class Top10Reducer extends Reducer<TotalLoanByBorrowerComposite, NullWritable, TotalLoanByBorrowerComposite, NullWritable>{
    private static int counter = 1;
    @Override
    protected void reduce(TotalLoanByBorrowerComposite key, Iterable<NullWritable> values, Context context) throws IOException, InterruptedException {
        //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
        
        for(NullWritable value : values){
            if(Top10Reducer.counter <=25){
                context.write(key,value);
                counter++;
            }
        }
    }
    
}
