/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_top10borrowers;

import java.io.IOException;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author vishalsatam
 */
public class TotalLoanAmountMapper extends Mapper<Object, Text, Text, DoubleWritable>{

    Text mapKey = new Text();
    DoubleWritable d = new DoubleWritable();
    
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
        try{
        String[]  tokens = UtilityFunction.parseCSVLine(value.toString());
        if(tokens[0].equals("id")){
            return;
        }
        
        if(tokens[10].trim().equals("")){
            return;
        }
        mapKey.set(tokens[10].trim().toUpperCase());
        d.set(Double.parseDouble(tokens[2].trim()));
        context.write(mapKey,d);
        }
        catch(Exception e){
            System.out.println(value);
        }
        
    }
    
}
