/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_top10borrowers;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author vishalsatam
 */
public class TotalLoanAmountReducer extends Reducer<Text, DoubleWritable, Text, BigDecimalWritableCustom>{

    @Override
    protected void reduce(Text key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
        //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
        BigDecimal count = new BigDecimal(0.0);
        
        for(DoubleWritable d : values){
            count = count.add(BigDecimal.valueOf(d.get()));
        }
        context.write(key,new BigDecimalWritableCustom(count.setScale(2)));
    }
    
}
