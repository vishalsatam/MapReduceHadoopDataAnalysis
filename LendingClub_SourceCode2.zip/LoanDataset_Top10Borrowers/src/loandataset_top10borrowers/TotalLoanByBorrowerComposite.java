/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_top10borrowers;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Objects;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

/**
 *
 * @author vishalsatam
 */
public class TotalLoanByBorrowerComposite implements Writable, WritableComparable<TotalLoanByBorrowerComposite>{

    private String  borrowerName;
    private String totalAmount;
    
    public TotalLoanByBorrowerComposite(){
        
    }
    
    public TotalLoanByBorrowerComposite(String borrowerName, String totalAmount){
        this.borrowerName = borrowerName;
        this.totalAmount = totalAmount;
    }

    public String getBorrowerName() {
        return borrowerName;
    }

    public void setBorrowerName(String borrowerName) {
        this.borrowerName = borrowerName;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    
    
    @Override
    public void write(DataOutput d) throws IOException {
       //hrow new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       d.writeUTF(borrowerName);
       d.writeUTF(totalAmount);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.borrowerName = di.readUTF();
        this.totalAmount = di.readUTF();
    }

    @Override
    public int compareTo(TotalLoanByBorrowerComposite o) {
        //-throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        try{
        BigDecimal b1 = new BigDecimal(this.totalAmount);
        
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
symbols.setGroupingSeparator(',');
symbols.setDecimalSeparator('.');
String pattern = "#.#";
        DecimalFormat decimalFormat = new DecimalFormat(pattern, symbols);
decimalFormat.setParseBigDecimal(true);

// parse the string
BigDecimal bigDecimal = (BigDecimal) decimalFormat.parse(o.getTotalAmount());
System.out.println(bigDecimal);

    if(b1.equals(bigDecimal)){
        return this.borrowerName.compareTo(o.getBorrowerName());
    }
    else{
        return -1*b1.compareTo(bigDecimal);
    }
        
        }
        catch(Exception e){
            System.out.println("Exception in parsing\n"+o.getTotalAmount());
        }
        return 0;
    }

    @Override
    public String toString() {
        return borrowerName + "\t" + totalAmount;
    }



    
    
    

    
}
