/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loandataset_top10borrowers;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

/**
 *
 * @author vishalsatam
 */
public class TotalLoanByBorrowerCompositeKey implements Writable, WritableComparable<TotalLoanByBorrowerCompositeKey>{

    private String  borrowerName;
    private Double totalAmount;
    
    public TotalLoanByBorrowerCompositeKey(){
        
    }
    
    public TotalLoanByBorrowerCompositeKey(String borrowerName, Double totalAmount){
        this.borrowerName = borrowerName;
        this.totalAmount = totalAmount;
    }

    public String getBorrowerName() {
        return borrowerName;
    }

    public void setBorrowerName(String borrowerName) {
        this.borrowerName = borrowerName;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    
    
    @Override
    public void write(DataOutput d) throws IOException {
       //hrow new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       d.writeUTF(borrowerName);
       d.writeDouble(totalAmount);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.borrowerName = di.readUTF();
        this.totalAmount = di.readDouble();
    }

    @Override
    public int compareTo(TotalLoanByBorrowerCompositeKey o) {
        //-throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(o.getTotalAmount().equals(this.totalAmount)){
            return this.borrowerName.compareTo(o.getBorrowerName());
        }
        else{
            return -1*this.totalAmount.compareTo(o.getTotalAmount());
        }
    }

    @Override
    public String toString() {
        return borrowerName + "\t" + totalAmount;
    }



    
    
    

    
}
