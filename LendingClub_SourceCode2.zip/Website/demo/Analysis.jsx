import React from 'react';
import BackButton from './Common/BackButton';
import ImageGallery from 'react-image-gallery';
import {Row, Col} from 'react-bootstrap';
import "react-image-gallery/styles/css/image-gallery.css";
const descriptionText = [
  {
    heading: '',
    paragraphs: [
      ''
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: 'Top 25 Borrowers',
    paragraphs: [
      'Purpose : This analysis was performed to determine what emp_titles constitute the top 25 borrowers. The value for this is calculated using the sum of the funded amount for the loans. This analysis helps us understand the borrower profiles based on the total amount of loan borrowed.',
      'Result : The analysis conclusively determines that Teachers and Managers have the highest borrowed loans and Lending club should focus its marketing campaigns towards people from these professions. This might lead to increase in sales of loans.',
      'Map Reduce Design patterns : Filtering pattern - Top 25 analysis, Job Chaining to sort borrower amount in descending order and filter out top 25 borrowers. Secondary Sorting using Composite Key for Borrower and the sum of the amounts of loan.'
    ]
  },
  {
    heading: 'Exploratory analysis on the total loan amount issued by Date',
    paragraphs: [
      'Purpose : This analysis is performed to gain an insight into how the Lending Club is performing overall. A good indicator of this more than the overall profit made is the amount of loans that Lending Club is issuing. This analysis will help us understand the sales volume and investor confidence.',
      'Results : The analysis performed above confirms the understanding that Lending Club’s business is growing steadily since inception. We can also see that since 2012, there is an exponential increase in the amount of loans issued by Lending Club. These are positive indicators which point to increasing investor confidence and increasing volume loans being sanctioned.',
      'Map Reduce Design Patterns : Combiner Optimization using a single implementation for Reducer and Combiner class.'
    ]
  },
{
    heading: 'Exploratory Analysis on the average rate of interest grouped by various factors',
    paragraphs: [
      'Purpose : Interest Rate is the most important attribute for Lending Club’s business because this is what drives their income and helps to attract borrowers. This exploratory analysis performs summarization and computes the average of interest rates grouped by various factors such as term, home ownership, state, borrower grade, purpose and application type. These summarizations were performed to determine features that could adequately predict or affect the interest rate of a loan.',
      'For this analysis, the different features were emitted as key to be grouped and the interest rate was emitted as the value.',
      'Results : From the analysis conducted, we can clearly see a relationship between the borrower grade and the interest rate.',
      'The term of the loan has some effect on the rate of interest as we can see that the longer the term, higher the interest. We can also see that if the application type is Individual, the interest rate is lower as compared to the Joint applications. Although these factors seem to affect interest rates, the difference between the interest rate values is not considerable enough to be taken as features for regression.',
      'We can see from the whisker plots and the bar graph that Home ownership, State and Purpose do not affect the interest rate at all because the variation of the interest rates per feature type is not profound and cannot be considered as contributing features for interest rate. ',
      'Map Reduce Design Patterns : Numerical Summarization pattern for calculating Average of Interest Rates'
    ]
  },
{
    heading: 'Exploratory Analysis on the average rate of interest grouped by various factors',
    paragraphs: [
      'Purpose : Interest Rate is the most important attribute for Lending Club’s business because this is what drives their income and helps to attract borrowers. This exploratory analysis performs summarization and computes the average of interest rates grouped by various factors such as term, home ownership, state, borrower grade, purpose and application type. These summarizations were performed to determine features that could adequately predict or affect the interest rate of a loan.',
      'For this analysis, the different features were emitted as key to be grouped and the interest rate was emitted as the value.',
      'Results : From the analysis conducted, we can clearly see a relationship between the borrower grade and the interest rate.',
      'The term of the loan has some effect on the rate of interest as we can see that the longer the term, higher the interest. We can also see that if the application type is Individual, the interest rate is lower as compared to the Joint applications. Although these factors seem to affect interest rates, the difference between the interest rate values is not considerable enough to be taken as features for regression.',
      'We can see from the whisker plots and the bar graph that Home ownership, State and Purpose do not affect the interest rate at all because the variation of the interest rates per feature type is not profound and cannot be considered as contributing features for interest rate. ',
      'Map Reduce Design Patterns : Numerical Summarization pattern for calculating Average of Interest Rates'
    ]
  },
{
    heading: 'Exploratory Analysis on the average rate of interest grouped by various factors',
    paragraphs: [
      'Purpose : Interest Rate is the most important attribute for Lending Club’s business because this is what drives their income and helps to attract borrowers. This exploratory analysis performs summarization and computes the average of interest rates grouped by various factors such as term, home ownership, state, borrower grade, purpose and application type. These summarizations were performed to determine features that could adequately predict or affect the interest rate of a loan.',
      'For this analysis, the different features were emitted as key to be grouped and the interest rate was emitted as the value.',
      'Results : From the analysis conducted, we can clearly see a relationship between the borrower grade and the interest rate.',
      'The term of the loan has some effect on the rate of interest as we can see that the longer the term, higher the interest. We can also see that if the application type is Individual, the interest rate is lower as compared to the Joint applications. Although these factors seem to affect interest rates, the difference between the interest rate values is not considerable enough to be taken as features for regression.',
      'We can see from the whisker plots and the bar graph that Home ownership, State and Purpose do not affect the interest rate at all because the variation of the interest rates per feature type is not profound and cannot be considered as contributing features for interest rate. ',
      'Map Reduce Design Patterns : Numerical Summarization pattern for calculating Average of Interest Rates'
    ]
  },
{
    heading: 'Correlation of Inflation rate in US with the Interest Rate',
    paragraphs: [
      'Purpose : This analysis was carried out to explore  Correation between the Inflation rate in the US and the Average Interest rate being offered at Lending Club. The general rule of economics is that as the inflation rate rises, the interest rates drop and vice versa. This analysis would give us another feature, external to our primary dataset of Lending Club which might be important in predicting the interest rate.',
      'A map reduce job was created for determining the average rate of interest grouped by the issue date because it was a foreign key to be used to perform a map-side join with the US Inflation rates data. A map-side join was performed to determine correlation between the two datasets. Since the size of the inflation dataset was small, the Distributed Cache was utilized to improve performance by choosing a map-side join over a reduce-side join.',
      'Results : No correlation was found between the inflation rate and the average interest rate when mapped by the issue_date of the loan. ',
      'We can observe that between June 2009 and June 2010, the inflation rate in US dropped by a huge margin, in fact it became negative. But, contrary to our expectation, the average interest rate for Lending Club loans remained unaffected by this dramatic drop in inflation.',
      'From this, we can conclude that, since Lending Club is an autonomous peer to peer lending institution, which directly conducts business independently of the government with investors and borrowers, the interest rates do not fluctuate with fluctuations in the Inflation.',
      'Map Reduce Design Patterns : Numerical Summarization pattern for calculating average of interest rates. Combiner optimization with single implementation of Reducer used for both Reducer/Combiner. A Writable class was created to facilitate the single Reducer/Combiner implementation.',
      'Job chaining used to pass the output of the Average computation map reduce job as the input to the MR job that performs the Map side Join Pattern with Distributed Cache.'
    ]
  },
{
    heading: 'Predicting Interest Rate using Linear Regression',
    paragraphs: [
      'Purpose : This analysis is to provide a prediction model based on which we can predict the interest rate of a loan application. We have been building up this predictive analysis so far by performing exploratory analysis to find out the appropriate features which can be used to predict the rate of interest of an application. We have seen that the Borrower grade is the most important feature that can determine the Interest rate associated with the loan application.',
      'The dataset has 2 grade related features, i.e the Borrower Grade (grade), and the Borrower Sub-Grade(sub_grade).',
      'Map Reduce Design Patterns : Numerical Summarization pattern for calculating average of interest rates. Combiner optimization with single implementation of Reducer used for both Reducer/Combiner. A Writable class was created to facilitate the single Reducer/Combiner implementation.',
      'Job chaining used to pass the output of the Average computation map reduce job as the input to the MR job that performs the Map side Join Pattern with Distributed Cache.'
    ]
  },
{
    heading: 'Predicting Interest Rate using Linear Regression',
    paragraphs: [
      'Purpose : This analysis is to provide a prediction model based on which we can predict the interest rate of a loan application. We have been building up this predictive analysis so far by performing exploratory analysis to find out the appropriate features which can be used to predict the rate of interest of an application. We have seen that the Borrower grade is the most important feature that can determine the Interest rate associated with the loan application.',
      'The dataset has 2 grade related features, i.e the Borrower Grade (grade), and the Borrower Sub-Grade(sub_grade).',
      'Map Reduce Design Patterns : Numerical Summarization pattern for calculating average of interest rates. Combiner optimization with single implementation of Reducer used for both Reducer/Combiner. A Writable class was created to facilitate the single Reducer/Combiner implementation.',
      'Job chaining used to pass the output of the Average computation map reduce job as the input to the MR job that performs the Map side Join Pattern with Distributed Cache.'
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  },
  {
    heading: '',
    paragraphs: [
      
    ]
  }
  

]
const rightPoints = [
  {
    heading: '',
    topText: '',
    bullets: [
      
    ]
  },
  {
    heading: 'Data Cleaning',
    topText: '',
    bullets: [
      '1.	Developed a UtilityFunctions class to develop a customized effective parser that suits the main dataset of Lending Club.',
'2.	The values in all the date fields were re-formatted by writing a generic function which was added in the UtilityFunctions class. This function transforms all the dates into MMM-YYYY format from the inconsistently occurring MMM-YY and/or YY-MMM format to prevent future ambiguities as well as issues in BI tools.',
'3.	Separated the dataset into 2 parts, one that contains only the descriptions and the ID and the other with the remaining fields to avoid parsing issues and to increase performance as most of our analysis does not require the loan descriptions. Performance gain is observed because most of our analysis is performed on the main dataset which doesn’t contain the descriptions.',
'4.	Purpose has been cleaned to include the correct types of loans that Lending Club offers.',
'5.	Term has been cleaned to remove “months”. This is redundant and adds space overhead.',
'6.	We are not doing anything for missing values because these will be handled when we parse and analyze the individual fields.',
'7.	Loan title has been cleaned to remove unnecessary double quotations and commas to reduce parsing issues.',
'8.	Removed URL from the dataset as we don’t require this.'

    ]  
  },
  {
    heading: '',
    topText: '',
    bullets: [
      
    ]
  },
  {
    heading: '',
    topText: '',
    bullets: [
      

    ]  
  },
    {
    heading: '',
    topText: '',
    bullets: [
      

    ]  
  },
    {
    heading: '',
    topText: '',
    bullets: [
      

    ]  
  },
    {
    heading: '',
    topText: '',
    bullets: [
      

    ]  
  },
    {
    heading: '',
    topText: '',
    bullets: [
      

    ]  
  },
    {
    heading: 'Linear Regression - Data Preparation',
    topText: '',
    bullets: [
      'Grades have been transformed as A3 = 3, B4 = 9, G3 = 33',
      'Linear Correlation exists between Grade/Subgrade and the Interest rate',
      'Job chaining is used to chain 3 MR jobs together',
      'Job 1 - performs data transformation and partitions data into train 90% and test 10%'
    ]  
  },
    {
    heading: 'Linear Regression - Derive Model',
    topText: '',
    bullets: [
      'Job 2 - Uses Combiner Optimization to calculate mean vaue of Interest and Borrower Grade',
      'Job 3 - This is the main MR job that performs Standard Deviation which is used to derive Linear Regression Model'
    ]  
  },
    {
    heading: '',
    topText: '',
    bullets: [
      

    ]  
  },
    {
    heading: 'Linear Regression - Scoring The Model',
    topText: '',
    bullets: [
       'The model is scored by calculating the standard error'

    ]  
  },
    {
    heading: 'Linear Regression - Testing and Estimation',
    topText: '',
    bullets: [
       'The estimated values are calculated on the test data according to the model',
       'Map Reduce Design Patterns : Job Chaining, Numerical Summarization (Standard Deviation and Average), Data Organization Pattern ( Partitioning ),',
       'Filtering pattern used to Split data, Combiner Optimization using a single implementation for Reducer/Combiner and created a custom Writable class for outputting values from Mapper and Combiner.'

    ]  
  },
    {
    heading: 'Improving Investor Strategy - Prescriptive Analysis',
    topText: 'Checking Investor Stakes ',
    bullets: [
       'Purpose : This prescriptive analysis is performed to analyze the current status of the different aspects of the Lending Club dataset that an Investor might be informed of to make better decisions in order to improve investment strategy to maximize profit and minimize default. ',
       'A MR job was configured to calculate the difference in the funded amount for a loan and the amount funded by investors to understand the percentage of the investors stake in a loan.',
       'Result : From the above investor stake chart, we can see that the investors are mostly diversified and have a high percentage of stakes in every type of loan. The most intersting fact that we can derive from this chart is that there is less interest among investors for educational loans. We will attempt to understand more on the condition of Educational loans from a investor viewpoint.',
        'Map Reduce Design Patterns : Combiner Optimization used with single implementation for Reducer/Combiner while determining Stake Ratio.'
    ]  
  },
    {
    heading: 'Improving Investor Strategy - Prescriptive Analysis',
    topText: 'Analyzing profit and Deficit amount (%)',
    bullets: [
      'We calculate 4 major parameters for this analysis. The profit percentage and amounts per purpose and the Deficit amount and the deficit amount percentage.',
      'The Profit is calculated as the difference of the total amount of money received from the borrowers and the amount of money funded by Lending Club. The received money includes the interest that we get from the borrowers. The deficit amount is the difference between the projected income ( sum of the amount of money which that type of loan could have fetched ) and the actual income (sum of the amount money actually received back from the borrowers)',


    ]  
  },
    {
    heading: 'Improving Investor Strategy - Prescriptive Analysis',
    topText: 'Analyzing profit and Deficit amount',
    bullets: [
      'Result : When we see this analysis, it is quite evident that Educational Loans don’t have large sums of money coming in as profit as compared to credit cards or debt_consolidation but the deficit amount, i.e the difference between the money that could have been made vs the money actually made is the least in Educational Loans. This means that the risk of default of the difference in the actual income and projected income is lesser as compared to say small businesses.',
      'Educational loans can actually be looked at as a viable option in future to increase profits and have better estimations and results in terms of projected income. This way the investors get to meet their quarterly goals for achieving profit.',
      'Another observation that we can make is that currently, the investors seem to be taking an aggressive stance by investing in credit cards. The deficit percentage is quite low. Also, credit cards bring in the highest profit as compared to any other type of loan. This might be a good thing, but according to the deficit amount, credit cards and debt consolidation are way higher. The investors might want to consider moving away from these types of loans by taking a moderate stance and look at investing in loans that have lower deficit amount thereby having a lower chance of defaulting.',
      '',
      'Map Reduce Design Patterns : Numerical Summarization patterns used to compute values for profit, profit %, deficit and deficit %. Custom Writable created for writing funded amount (investment), amount received (income) and projected profit.'

    ]  
  },
    {
    heading: 'Loan Defaults Exploratory Analysis',
    topText: '',
    bullets: [
      'Purpose : This analysis is performed to understand characteristics of loans that default. A good indicator to understand this is the default rate of the loans in our dataset based on different factors such as Borrower Grade, Home Ownership, Purpose, Term, State. We are trying to determine which features affect the default rate by plotting the variation by the feature.',
      'Results : As we can see in the above charts, the default rate has a direct linear relation with the borrower grade. We have also seen this pattern while performing linear regression for predicting interest rates. This outcome is as expected because as the grade increases from A to G, the risk associated with the borrower profile increases and hence the probability of default tends to rise.'


    ]  
  },
    {
    heading: 'Loan Defaults Exploratory Analysis',
    topText: '',
    bullets: [
      'The default rate has remained unaffected and roughly the same since the beginning of 2008 till date. This is an indicator that Lending Club is doing something wrong in terms of selecting loans. According to this statistic, we can conclude that we must try to come up with a predictive tool to predictLoan Defaults.',
      'The default rate also seems to vary by the home ownership. As expected, the borrowers who RENT are more likely to default as compared to borrowers who are home owners or are on mortgage. It is interesting to note that the borrowers on mortgage have a lower default rate as compared to borrowers that own homes.',
      'Loan default rates change considerably dramatically by purpose and there seems to be a linear correlation between purpose and the default rate. It is interesting to note again that Education has higher default rates. It is possible that the investors are being wary of investing in loans that come under that purpose. As a result of this, we are left with a confusion as to whether a higher deficit amount and lower profit is a better option or should a higher loan default ratio matter.',
      'We can observe that the loan default rate is higher for loans that have a higher term. This is expected because people tend to default more when they have a larger overall amount to pay back. And there could also be external factors which affect the loan re-payment.',
      'It is very straightforward to notice that the state in which the loan was issued does not have much effect on the loan and there is little variance between the loan default rates of different states.'



    ]  
  },
    {
    heading: 'Correlation of Rejected Loans and Default Rates per State',
    topText: '',
    bullets: [
      'Purpose : This analysis is to determine if there is a correlation between the loan default rate and the number of loan rejections per state. An inner join was performed on the Rejects dataset and the default rate by state that we obtained during the previous analysis.',
      'Results :  The hypothesis was that the number of rejections would rise if the default rate in a state was high but this analysis revealed no concrete evidence to support this claim.',
      'Map Reduce Design Patterns : Reduce side join pattern.'

    ]  
  },
    {
    heading: 'Intent Analysis of Loan Descriptions provided by Borrower',
    topText: '',
    bullets: [
      'Purpose : The borrower usually provides a detailed description of the purpose with the loan application. This can be considered as an important feature in order to form a profile of the borrower to analyze and rate the borrowers intent. To rate a borrower’s intent, intent analysis is performed on the loan description. A score of +1 is assigned for every positive word and a score of -1 is assigned to every negative intent word. The overall intent score is calculated by adding the scores of the individual words.',
      'A map reduce job is run to join together the loan descriptions dataset and the main dataset to have the Loan Status and the Descriptions in one file. The ID is used as the foreign key to perform the inner join over these two datasets.',
      'We use the Bloom Filter MR filtering pattern to check for matching intent words in the positive and negative intent words list. This was done to improve performance.',
      'Result : The intent score has been calculated during the Map phase and the average of all the individual scores has been computed in the Reduce phase. The key Loan Status and value of intent score per loan was emitted by the Mapper and used in the reducer to compute averages of the intent score.',
      'The conclusion of this analysis is that the loans that are in the Fully Paid status have a higher intent score on an average as compared to the loans that have Defaulted. This can also be used as a feature or parameter in predicting or to at least caution to Lending Club as to exercise more scrutiny for such loan applications that have a lower intent score.'

    ]  
  },
    {
    heading: 'Predicting if a Loan will Default',
    topText: 'Model',
    bullets: [
      'Purpose : This analysis is a predictive analysis to determine if a particular loan will default based on features provided. The prediction algorithm used is Multiclass Decision Forest algorithm. From the previous exploratory analysis, we could determine that grade, home ownership and purpose can be important categorical features that can help in predicting if a loan will default. For increasing accuracy, we can also consider the annual income and, interest rate and dti (debt to income ratio) as numerical features that might supplement the categorical features.',
      'We used the MR filtering pattern to filter out the relevant data i.e, loans for which a status of either a Good Loan or Default can be determined. Only the historical data was selected which could be used to train the model effectively. The current and issued loans cannot be used to train this model. The irrelevant columns were also removed as a part of this MR job.',
      'Microsoft Azure Machine Learning studio was used to develop the model.'
    ]  
  },
    {
    heading: 'Predicting if a Loan will Default',
    topText: 'Evaluation',
    bullets: [
      'Results : The model that was computed by Azure was 73% accurate overall and could predict if a loan would default correctly 21.7% of the time.',
      'It is understandable that this level of accuracy is very less and more research is required to come up with additional (maybe external) features to improve the prediction model.',
      'Map Reduce patterns : Filtering patterns were used to filter out current loans for which we couldn’t use as training data such as current or issued loans. This filtered data was provided as input to Microsoft Azure Machine Learning Studio to develop the model.'

    ]  
  },
    {
    heading: 'Word Count Analysis for determining Hot Words',
    topText: '',
    bullets: [
      'Purpose  : We have categorized the intent words that are being used to calculate an intent score in the previous analysis. This analysis calculates the frequency of useful words from the loan descriptions to prepare a list of hot words. This can be used to improve the future models and also can be used by linguistic research team to increase accuracy in Natural language Techniques to improve the accuracy of the intent score that is being assigned to a loan description in future.',


    ]  
  }



]
export default class Analysis extends React.Component {
  constructor(props) {
    super(props);
    this.state= {
      displayIndex: 0
    }
    this.showDescription = this.showDescription.bind(this);
    this.showBulletPoints = this.showBulletPoints.bind(this);
    this.onSlideImage = this.onSlideImage.bind(this);
  }
  onSlideImage(index) {
    console.log('Image loaded ', index)
    this.setState({
      displayIndex: index
    })
  }
  showDescription() {
    let entries = [], i = 0;
    let para = descriptionText[this.state.displayIndex].paragraphs;
    for(let x in para) {
      entries.push(
        <p key={i}>{para[x]}</p>
      )
      i++;
    }
    return (
      <div id='bottomDesc'>
        <h3>{descriptionText[this.state.displayIndex].heading}</h3>
        <span>{entries}</span>
      </div>
    )
  }
  showBulletPoints() {
    let entries = [], i = 0;
    let bullets = rightPoints[this.state.displayIndex].bullets;
    for(let x in bullets) {
      entries.push(
        <li key={i}>{bullets[x]}</li>
      )
      i++;
    }
    return (
      <div id="rightBullet">
        <h3>{rightPoints[this.state.displayIndex].heading}</h3>
        <p>{rightPoints[this.state.displayIndex].topText}</p>
        <ul>{entries}</ul>
      </div>
    )
  }
  render() {
    const images = [
      {
        original: '../lib/images/mainImage.png',
        thumbnail: '../lib/images/mainImage.png'
      },
      { 
        original: '../lib/images/datacleaning.png',
        thumbnail: '../lib/images/datacleaning.png'
      },
      {
        original: '../lib/images/top25borrowers.png',
        thumbnail: '../lib/images/top25borrowers.png'
      },
      {
        original: '../lib/images/loanamounts_byissuedate.png',
        thumbnail: '../lib/images/loanamounts_byissuedate.png'
      },
      {
        original: '../lib/images/interestrate_term_homewoner_state.png',
        thumbnail: '../lib/images/interestrate_term_homewoner_state.png'
      },
      {
        original: '../lib/images/interestrate_borrowergrade_purpose.png',
        thumbnail: '../lib/images/interestrate_borrowergrade_purpose.png'
      },
      {
        original: '../lib/images/interestrate_apptype_state.png',
        thumbnail: '../lib/images/interestrate_apptype_state.png'
      },
      {
        original: '../lib/images/InflationInterest_Date.png',
        thumbnail: '../lib/images/InflationInterest_Date.png'
      },
      {
        original: '../lib/images/linreg_interestborrower_scatter.png',
        thumbnail: '../lib/images/linreg_interestborrower_scatter.png'
      },
      {
        original: '../lib/images/linregformula.png',
        thumbnail: '../lib/images/linregformula.png'
      },
      {
        original: '../lib/images/linregresults.png',
        thumbnail: '../lib/images/linregresults.png'
      },
      {
        original: '../lib/images/linreg_stderr.png',
        thumbnail: '../lib/images/linreg_stderr.png'
      },
      {
        original: '../lib/images/linregestimates.png',
        thumbnail: '../lib/images/linregestimates.png'
      },
      {
        original: '../lib/images/investorstake.png',
        thumbnail: '../lib/images/investorstake.png'
      },
      {
        original: '../lib/images/investorstake_2.png',
        thumbnail: '../lib/images/investorstake_2.png'
      },
      {
        original: '../lib/images/investorstake_3.png',
        thumbnail: '../lib/images/investorstake_3.png'
      },
      {
        original: '../lib/images/defaultrate_1.png',
        thumbnail: '../lib/images/defaultrate_1.png'
      },
      {
        original: '../lib/images/defaultrate_3.png',
        thumbnail: '../lib/images/defaultrate_3.png'
      },
      {
        original: '../lib/images/defaultrate_2.png',
        thumbnail: '../lib/images/defaultrate_2.png'
      },
      {
        original: '../lib/images/sentimentscore.png',
        thumbnail: '../lib/images/sentimentscore.png'
      },
      {
        original: '../lib/images/defaultrate_prediction_setup.PNG',
        thumbnail: '../lib/images/defaultrate_prediction_setup.PNG'
      },
      {
        original: '../lib/images/defaultrate_prediction_score.png',
        thumbnail: '../lib/images/defaultrate_prediction_score.png'
      },
      {
        original: '../lib/images/wordcount.png',
        thumbnail: '../lib/images/wordcount.png'
      }
      
    ]
  
    return (
      <Row style={{padding: '30px', paddingRight: '40px'}}>
       <Col md={8}>
          <ImageGallery
            items={images}
            slideInterval={2000}
            onSlide={this.onSlideImage}/>
          {this.showDescription()}
        </Col>
        <Col id='rightBulletCol' md={4}>
          {this.showBulletPoints()}
        </Col>
      </Row>
    )
  }
}