/* eslint-disable no-alert */
import React from 'react';
import {browserHistory} from 'react-router';
import {
  Dashboard,
  Sidebar,
} from '../src/index';

const navMenu = () => ([]);

const sb = () => ([
  // <Sidebar.Search key="1" />,
  <Sidebar.Menu header="" key="2">
    <Sidebar.Menu.Item icon={{ className: 'fa-dashboard' }} title="Dashboard" onClick={() => {browserHistory.push('/')}} />
    <Sidebar.Menu.Item icon={{ className: 'fa-bar-chart' }} title="Analysis" onClick={() => {browserHistory.push('/analysis')}} />
    <Sidebar.Menu.Item icon={{ className: 'fa-edit' }} title="Loan Default Predictor" onClick={() => {browserHistory.push('/predictor')}} />
  </Sidebar.Menu>,
]);

const logoLg = () => (
  <span></span>
);

const logoSm = () => (
  <span></span>
);

const App = ({ children, theme }) => (
  <Dashboard
    logoLg={logoLg()}
    logoSm={logoSm()}
    logoOnClick={() => {browserHistory.push('/')}}
    navbarChildren={navMenu()}
    sidebarChildren={sb()}
    sidebarMini
    theme={theme}
  >
    {children}
  </Dashboard>
);

App.propTypes = {
  children: React.PropTypes.node,
  theme: React.PropTypes.string,
};

export default App;
