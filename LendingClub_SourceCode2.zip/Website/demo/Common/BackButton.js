import React from 'react';
import {browserHistory} from 'react-router';

const BackButton = () => (
  <i className="fa fa-chevron-circle-left text-info" style={{fontSize: '30px'}} aria-hidden="true" onClick={() => {browserHistory.push('/')}}></i>
);

export default BackButton;
