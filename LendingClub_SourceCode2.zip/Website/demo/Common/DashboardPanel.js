import React from 'react';
import {browserHistory} from 'react-router';

export default class DashboardPanel extends React.Component {
  constructor(props) {
    super(props);
  }  
  render() {
    return (
      <div style={{padding: '50px', width: '95%', backgroundColor: '#f2f2f2', textAlign: 'center'}} onClick={() => {browserHistory.push(this.props.link)}}>
        <i className={`fa ${this.props.iconClass} ${this.props.colorClass}`} style={{fontSize: '155px'}} aria-hidden="true"></i><br/><br/>
        <h3>{this.props.titleText}</h3>
      </div>
    );
  }
}


