import React from 'react';
import {browserHistory} from 'react-router';
import { Row, Col } from 'react-bootstrap';
import DashboardPanel from './Common/DashboardPanel';

const Home = () => (
  <div style={{padding: '25px 30px 0 30px'}}>
    <div>
        <h1>Dashboard</h1>
    </div>
    <div style={{padding: '30px 0 0 10px'}}>
      <Row>
        <Col sm={12} md={6} lg={6}>
          <DashboardPanel link='/analysis' titleText='Analysis' iconClass='fa-bar-chart' colorClass='text-info' />
        </Col>
        <Col sm={12} md={6} lg={6}>
          <DashboardPanel link='/predictor' titleText='Loan Default Predictor' iconClass='fa-edit' colorClass='text-info' />
        </Col>
      </Row>
    </div>
  </div>
);

export default Home;
