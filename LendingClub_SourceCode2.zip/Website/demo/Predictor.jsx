import React from 'react';
import BackButton from './Common/BackButton';
import $ from 'jquery';
import { Row, Col } from 'react-bootstrap';

export default class Predictor extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      output: ''
    }
  }
  sendRequest() {
    var toSend = [
            this.refs.interestRateRef.value,
            this.refs.gradeRef.value,
            this.refs.homeOwnershipRef.value,
            this.refs.annIncomeRef.value,
            this.refs.purposeRef.value,
            this.refs.DTIRef.value
          ];
    console.log(toSend);
    var aData = JSON.stringify(
      {
      "Inputs": {
        "input1": {
          "ColumnNames": [
            "int_rate",
            "grade",
            "home_ownership",
            "annual_inc",
            "purpose",
            "dti"
          ],
          "Values": [
            toSend
          ]
        }
      },
      "GlobalParameters": {}
    }
    );
  
    var thisRef = this;
    // var serviceUrl = "https://ussouthcentral.services.azureml.net/workspaces/eb03e38acbc34e54be27d32fd3150509/services/0dd5100f5ee342e182cb22ed641ff78c/execute?api-version=2.0&details=true";
    // var url = 'https://ussouthcentral.services.azureml.net/workspaces/eb03e38acbc34e54be27d32fd3150509/services/0bfceca3a5f046179d4319308bcb6009/execute?api-version=2.0&details=true';
    // var api_key = 'v3eY6LAL/shGhb/njhfC/KPmdTmz4qtz7074q+aFLdpgbdjLUNTO5pbvm/FH9q0oyKzap8a/lpl1uADIlbOvEw==';
    $.ajax({
        url: "http://localhost:3000/ajax",
        type: "POST",
        data: JSON.stringify(aData),
        contentType: "application/json",
        dataType: "json",
        success: function(data) {
            console.log(data);
            thisRef.setState({
              output: data.Results.output1.value.Values[0][8]
            })
            // alert(JSON.stringify(data.Results.output1.value.Values[0][8]))
        }
    });
  }
  valueChanged() {
    this.setState({
      output: ''
    })
  }
  render() {
  return (
      <div id='estimatePage' style={{padding: '25px 30px 0 30px'}}>
        <h1><BackButton /> Loan Default Predictor</h1>
        <Row>
        <Col md={6} style={{padding: '30px 0 0px 40px'}}>
            <div>
              <label>Interest Rate</label>
                <input type="number" onChange={this.valueChanged.bind(this)} ref='interestRateRef' />
             </div>
             <br/>
            <div>
              <label>Grade Values</label>
              <select onChange={this.valueChanged.bind(this)} ref="gradeRef">
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
                <option value="F">F</option>
                <option value="G">G</option>
              </select>
             </div>
            <br/>
            <div>
              <label>Home Ownership</label>
              <select onChange={this.valueChanged.bind(this)} ref="homeOwnershipRef">
                <option value="ANY">ANY</option>
                <option value="MORTGAGE">MORTGAGE</option>
                <option value="NONE">NONE</option>
                <option value="OTHER">OTHER</option>
                <option value="OWN">OWN</option>
                <option value="RENT">RENT</option>
              </select>
            </div>
            <br/>
            <div>
              <label>Annual Income</label>
                <input type="number" onChange={this.valueChanged.bind(this)} ref='annIncomeRef' />
            </div>
            <br/>
            <div>
              <label>Purpose</label>
              <select onChange={this.valueChanged.bind(this)} ref="purposeRef">
                <option value="car">car</option>
                <option value="credit_card">credit_card</option>
                <option value="debt_consolidation">debt_consolidation</option>
                <option value="educational">educational</option>
                <option value="home_improvement">home_improvement</option>
                <option value="house">house</option>
                <option value="major_purchase">major_purchase</option>
                <option value="medical">medical</option>
                <option value="moving">moving</option>
                <option value="other">other</option>
                <option value="renewable_energy">renewable_energy</option>
                <option value="small_business">small_business</option>
                <option value="vacation">vacation</option>
                <option value="wedding">wedding</option>
              </select>
            </div>
            <br/>
            <div>
              <label>DTI</label>
                <input type="number" onChange={this.valueChanged.bind(this)} ref='DTIRef' />
            </div>
            <br/>
            <br/>
            <button id='submitButton' onClick={this.sendRequest.bind(this)}>Submit</button>
         <br/>
      </Col>
      <Col id='result' md={6}>
        {this.state.output != '' ? 
         <div>
           <span>
            <i className={this.state.output == 'Good Loan' ? 'text-success fa fa-check' : 'text-danger fa fa-times'} aria-hidden="true"></i><br/><br/>
            <span className={this.state.output == 'Good Loan' ? 'text-success' : 'text-danger'}>{this.state.output}</span>
           </span>
         </div>
         :
         null
         }
      </Col>
      </Row>
      </div>
    );
  }
}