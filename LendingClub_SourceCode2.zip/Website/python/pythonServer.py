import json
import urllib2
import ast
from bottle import Bottle, request, response, run
app = Bottle()

@app.hook('after_request')
def enable_cors():
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'PUT, GET, POST, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token'

@app.route('/ajax', method=['OPTIONS', 'POST'])
def ajax():
    if request.method == 'OPTIONS':
        return {}
    else:
        d = ast.literal_eval(request.json)
        print '--------'
        print type(d)
        print d
        body = str.encode(json.dumps(d))
        url = 'https://ussouthcentral.services.azureml.net/workspaces/eb03e38acbc34e54be27d32fd3150509/services/0bfceca3a5f046179d4319308bcb6009/execute?api-version=2.0&details=true'
        api_key = 'v3eY6LAL/shGhb/njhfC/KPmdTmz4qtz7074q+aFLdpgbdjLUNTO5pbvm/FH9q0oyKzap8a/lpl1uADIlbOvEw=='
        headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ api_key)}
        req = urllib2.Request(url, body, headers)
        response = urllib2.urlopen(req)
        the_page = response.read() 
        return the_page

if __name__ == '__main__':
    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("--host", dest="host", default="localhost",
                      help="hostname or ip address", metavar="host")
    parser.add_option("--port", dest="port", default=3000,
                      help="port number", metavar="port")
    (options, args) = parser.parse_args()
    run(app, host='localhost', port=int(options.port))